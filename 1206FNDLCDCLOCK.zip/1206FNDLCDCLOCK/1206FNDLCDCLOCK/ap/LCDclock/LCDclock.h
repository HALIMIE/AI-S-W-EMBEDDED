﻿

#ifndef LCDCLOCK_H_
#define LCDCLOCK_H_
#include <avr/io.h>
#define F_CPU 16000000UL
#include <util/delay.h>
#include <stdio.h>
#include "../../Driver/BUTTON/button.h"
#include "../../Driver/FND/FND.h"
#include "../../periph/GPIO/GPIO.h"
#include "../../periph/TIM/TIM.h"
#include "../../common/TimeTick/TimeTick.h"
#include "../../Driver/LCD/LCD.h"
#include "../FNDclock/FNDclock.h"
void Clock_init();
void Clock_incsec();
void Clock_execute();
void StopWatch_run();
void StopWatch_init();
void StopWatch_incMilisec();
void StopWatch_eventCheck();
void StopWatch_execute();
void FND_colonON();
void FND_colonOff();
void Clock_eventCheck();
void Clock_run();
void SMClock();

enum{NORMAL, MODIFY,SM, HM};
void LCDClock_run();
void TimeClock_run();
void timeClockDispCheck();
void timeClockModiCheck();
void incHour();
void incMin();

#endif /* LCDCLOCK_H_ */