﻿
#ifndef BUTTON_H_
#define BUTTON_H_

#include <avr/io.h>  //추가
#define F_CPU 16000000UL
#include <util/delay.h>
#include "../../periph/GPIO/GPIO.h"

enum {PUSHED,RELEASED};

enum {ACT_NONE, ACT_PUSHED,ACT_RELEASED};
	
		
typedef struct _button          //구조체 만들기     //구조체랑 enum은 헤더에 저장 함수들은 c로
{
	volatile uint8_t *DDR;		//port
	
	volatile uint8_t *PIN;        //pin
	
	uint8_t pinNum;	//
	uint8_t prevState; // static
	
	
}button_t; //구조체 자료형 선언할때 이따구로 쓰겠다 하는거

void Button_init(button_t *btn, volatile uint8_t *ddr, volatile uint8_t *pin, uint8_t pinNum);

uint8_t Button_GetState(button_t *btn) ;



#endif /* BUTTON_H_ */