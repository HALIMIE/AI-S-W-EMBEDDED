﻿#include "LCDclock.h"
#include "../../Driver/LCD/LCD.h"
#include "../../Driver/FND/FND.h"

uint16_t milisec;
uint8_t sec, min, hour;
button_t btnMODE, btnMODIFY, btnIH, btnIM,btnReset;
uint8_t ClockState,timeClockModiState ;
	
uint16_t SMData;
uint16_t HMData;




	
void Clock_init()
{
	milisec = 0;
	sec = 55;
	min =59;
	hour = 23;
	ClockState =HM ;
	timeClockModiState = NORMAL;
	FND_init();
	Button_init(&btnMODE,&DDRA,&PINA,0);
	Button_init(&btnMODIFY,&DDRA,&PINA,1);
	Button_init(&btnIH,&DDRA,&PINA,2);
	Button_init(&btnIM,&DDRA,&PINA,3);
	//Button_init(&btnReset,&DDRA,&PINA,0);
	TIM0_OVF_init();
	TIM2_CTC_init();
}

void Clock_incsec()
{

	milisec = (milisec+1)%1000;
	//if(milisec<500) FND_colonOn();    // :껏다켰다하는 부분
	//else FND_colonOff();
	
	
	//1~ 999까지 리턴해서 isr가는데 999+1 0 되면 리턴안하구 밑으로감
	if(milisec) return;
	
	
	sec = (sec+1) % 60;
	if(sec) return;
	
	min = (min+1) % 60;
	if(min) return;
	
	hour = (hour+1) %24;
}

void Clock_eventCheck()
{
	
	switch(timeClockModiState)
	{
		case NORMAL :
		if(Button_GetState(&btnMODIFY)==ACT_RELEASED)
		{
			timeClockModiState = MODIFY;
			ClockState = HM ;
		}
		timeClockDispCheck();
		break;
		
		case MODIFY :
		if(Button_GetState(&btnMODIFY)==ACT_RELEASED)
		{
			timeClockModiState = NORMAL;
			ClockState = HM ;
			sec = 0;       //modify 나왔을떄 초0으로 초기화 
			milisec = 0;
			
		}
		timeClockModiCheck();
		
		break;
		
		
		//stopWatchState = STOP;
	}

}

void timeClockDispCheck()
{
	switch(ClockState)
	{
		case HM:
		if(Button_GetState(&btnMODE) ==ACT_RELEASED)
		{
			ClockState = SM;
		}
		break;
		
		case SM:
		if(Button_GetState(&btnMODE) ==ACT_RELEASED)
		{
			ClockState = HM;
		}
		break;
	}
}

void timeClockModiCheck()
{
	if(Button_GetState(&btnIH) == ACT_RELEASED)
	{
		incHour();
	}
	else if(Button_GetState(&btnIM) == ACT_RELEASED)
	{
		incMin();
	}
}

void incHour()
{
	hour= (hour+1)%24;
	
}

void incMin()
{
	if(min>=60)
	min=0;
	
	min++;
}
void TimeClock_run()
{
	
	static uint8_t prevSec = 0xff; //0x00이면 처음에는 안찍히니깐 if문의 조건이 거짓이되니까
	
	//LCD
	if(sec != prevSec)  //ms데이더값때말고 sec만 받기위해 1초마다만 데이터만 받게
	{
		prevSec = sec;
	
		char buff[20];
		sprintf(buff,"TIME CLOCK");
		LCD_writeStringXY(0,3,buff);
		sprintf(buff,"%02d:%02d:%02d",hour,min,sec);
		LCD_writeStringXY(1,4,buff);
	}
	
	//FND
	
}


//LCD
#if 0

void Clock_init()
{
	milisec = 0;
	sec = 55;
	min =59;
	hour = 23;
	ClockState =HM ;
	FND_init();
	Button_init(&btnSW,&DDRA,&PINA,0);
	Button_init(&btnMODIFY,&DDRA,&PINA,1);
	Button_init(&btnIH,&DDRA,&PINA,2);
	Button_init(&btnIM,&DDRA,&PINA,3);
	TIM0_OVF_init();
	TIM2_CTC_init();
}

void Clock_incsec()
{

	milisec = (milisec+1)%1000;
	//if(milisec<500) FND_colonOn();    // :껏다켰다하는 부분
	//else FND_colonOff();
	
	
	     //1~ 999까지 리턴해서 isr가는데 999+1 0 되면 리턴안하구 밑으로감
	if(milisec) return;
	
	
	sec = (sec+1) % 60;
	if(sec) return;
	
	min = (min+1) % 60;
	if(min) return;
	
	hour = (hour+1) %24;
}
void LCDClock_run()
{
	char buff[15];
	
	char Ho[3];
	char Mi[3];
	char Se[3];
	char tim[10];
	sprintf(buff,"TIME CLOCK");
	LCD_writeStringXY(0,0,buff);
	
	//sprintf(tim,"% d: %d: %d",hour, min, sec);
	//LCD_writeStringXY(1,1,tim);
	
	
	sprintf(Ho,"%d: "  ,hour );
	LCD_writeStringXY(1,0,Ho);
	sprintf(Mi,"%d: "  ,min );
	LCD_writeStringXY(1,4,Mi);
	sprintf(Se,"%d "  ,sec );
	LCD_writeStringXY(1,8,Se);
	
		

}
#endif


//FND
#if 0

void Clock_eventCheck()
{
	
	switch(ClockState)
	{
		case SM :
		if(Button_GetState(&btnSW)==ACT_RELEASED)
		{
			ClockState = HM;
		}
		//else if(Button_GetState(&btnReset)==ACT_RELEASED)
		//{
			//stopWatchState = RESET;
		//}
		break;
		
		case HM :
		if(Button_GetState(&btnSW)==ACT_RELEASED)
		{
			ClockState = SM;
		}
		//else if(Button_GetState(&btnMODIFY)==ACT_RELEASED)
		//{
			//ClockState = MODIFY;
			//
		//}
		
		break;
		
		
		//stopWatchState = STOP;
	}

}
void Clock_execute()
{

	
	   //천자리에 min의 1의 자리를 넣고+백에자리에는  +십 + 일 :::: min의1의자리  sec10 sec1 mili*100
	
	
	
	switch(ClockState)
	{
		case SM :
	     clock_SM();
		//else if(Button_GetState(&btnReset)==ACT_RELEASED)
		//{
		//stopWatchState = RESET;
		//}
		break;
		
		case HM :
		 clock_HM();
		//else if(Button_GetState(&btnMODIFY)==ACT_RELEASED)
		//{
			//ClockState = MODIFY;
			//
		//}
		//
		break;
		
	}
	
	
	
	//
	//if(ClockState == SM)
	//{
		//FND_setfndData(SMData);
	//
	//}
//
	//else if(ClockState == HM)
	//{
	  //FND_setfndData(HMData);
	//}
	//else if(ClockState == MODIFY)
	//{
		//if(Button_GetState(&btnIH)==ACT_RELEASED)
		//{
			//hour++;
		//}
		//else if(Button_GetState(&btnIM)==ACT_RELEASED)
		//{
			//min++;
		//}
		//else if(Button_GetState(&btnMODIFY)==ACT_RELEASED)
		//{
			//ClockState = SM;
		//}
		//FND_setfndData(HMData);
		//
	//}
	//
	
}


void Clock_run()
{
	Clock_eventCheck();
	Clock_execute();
	
}

void clock_HM()
{
	
	
	
	HMData = (hour*100)+(min);
	SMData = (sec*100)+(milisec/10);
	sprintf(buff,"counter : %d"  , counter++);
	LCD_writeStringXY(0,0,buff);
	
}
void clock_SM()
{
	
	//if(milisec%100 <50) FND_colonOn();     // :깜빡거리는부분
	//else FND_colonOff();
	
	
	HMData = (hour*100)+(min);
	SMData = (sec*100)+(milisec/10);
	FND_setfndData(SMData);
	
}
#endif