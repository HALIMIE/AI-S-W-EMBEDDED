﻿/*
 * SL.h
 *
 * Created: 2024-12-01 오후 6:51:25
 *  Author: 임하림
 */ 


#ifndef SL_H_
#define SL_H_
#define F_CPU 16000000UL
#include <avr/io.h>
#include <util/delay.h>

#include "../../DRIVER/SLBTN/Button.h"
#include "../../DRIVER/SLLED/LED.h"
#define B_AUTO			0
#define B_MANUAL		1
#define B_SWITCHING		2
enum{OFF};
enum{bNext,bPrev};
enum{L0,L1,L2,L3,L4};        //  enum{RED_GREEN, RED_YELLOW,GREEN_RED,YELLOW_RED};

void Light_Off();                             //void TrafficSignal_Auto();
void Light_1();                             //void TrafficSignal_Manual();
void Light_2();                             //void TrafficSignal_RedGreen();
void Light_3();                             //void TrafficSignal_RedYellow();
void Light_4();                             //void TrafficSignal_GreenRed();
                             
void SL_init();                             //void TrafficSignal_init();
void SL_execute();                            //void TrafficSignal_execute();




#endif /* SL_H_ */