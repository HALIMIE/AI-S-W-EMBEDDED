﻿
#ifndef COLCK_H_
#define COLCK_H_


#include <avr/io.h>
#define F_CPU 16000000UL
#include <util/delay.h>
#include <stdio.h>
#include "../../Driver/BUTTON/button.h"
#include "../../Driver/FND/FND.h"
#include "../../periph/GPIO/GPIO.h"
#include "../../periph/TIM/TIM.h"
#include "../../common/TimeTick/TimeTick.h"
void Clock_init();
void Clock_incsec();
void Clock_execute();
void StopWatch_run();
void StopWatch_init();
void StopWatch_incMilisec();
void StopWatch_eventCheck();
void StopWatch_execute();
void FND_colonON();
void FND_colonOff();
void Clock_eventCheck();
void Clock_run();
void SMClock();
enum{SM, HM, MODIFY};
void LCDClock_run();

#endif /* COLCK_H_ */