#define F_CPU 16000000UL
#include <avr/io.h>
#include <avr/interrupt.h>
#include <util/delay.h>
#include <avr/interrupt.h>
#include "Driver/FND/FND.h"
#include "Driver/BUTTON/button.h"
#include "periph/GPIO/GPIO.h"
#include "periph/TIM/TIM.h"
#include "common/TimeTick/TimeTick.h"
#include "ap/CLOCK/CLOCK.h"

ISR(TIMER0_OVF_vect)
{
	FND_ISR_Process();
	TCNT0 =131;
	incTick();
}
ISR(TIMER2_COMP_vect)

{
	Clock_incsec();
}
int main()
{
	Clock_init();
	sei();
	while(1)
	{
		clock_run();
	}
	
	
}








#if 0

ISR(TIMER0_OVF_vect) //인터럽트 발생하면 일로옵니다  이  ISR이 호출되려면 정확히 1m/s?
{
	FND_ISR_Process();  //초기화 
	// FND_dispNum(fndData);
	TCNT0 = 131;
	incTick();
	
	
	
}
ISR(TIMER2_COMP_vect) //인터럽트 발생하면 일로옵니다  이  ISR이 호출되려면 정확히 1m/s?
{
	
	Clock_incsec();
	
	
}

int main(void)
{
	Clock_init();
	sei();
	
    /* Replace with your application code */
    while (1) 
    {
		Clock_execute();
		
    }
}

#endif