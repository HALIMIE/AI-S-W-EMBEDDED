#include <stdio.h>
void func(void)
{
	printf("func: Hello!\n");
}
