#include <stdio.h>
#include <assert.h>

int main()
{
    int x;
    assert(1 == 2);
    scanf("%d", &x);
    printf("%d", x * 10);
    return 0;
}