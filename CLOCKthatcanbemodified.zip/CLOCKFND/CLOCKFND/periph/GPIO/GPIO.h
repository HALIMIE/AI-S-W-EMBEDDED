﻿#ifndef GPIO_H_
#define GPIO_H_
#include <avr/io.h>
#define F_CPU 16000000UL
#include <util/delay.h>

enum {OUTPUT,INPUT};
	
enum {GPIO_RESET, GPIO_SET};
	
void Gpio_initPort(volatile uint8_t *DDR, uint8_t dir);
	
void Gpio_initPin(volatile uint8_t *DDR, uint8_t pinNum , uint8_t dir); //pinNum은 몇번째 핀인지 1개 핀에 대한 초기화



//output - port 8EA
void Gpio_writePort(volatile uint8_t *PORT, uint8_t data); //어떤 포트를 쓸껀지에대한함수 , 매개변수는 주소값에 대한 포인터 변수 와 어떤 값을 대입하고 싶은지write 값





//output - pin 1EA

void Gpio_writePin(volatile uint8_t *PORT, uint8_t pinNum, uint8_t state); // 마지막 state 매개변수는 0 올 1 출력하는변수

//input - port 8EA
uint8_t Gpio_readPort(volatile uint8_t *PIN);

//input - pin 1EA
uint8_t Gpio_readPin(volatile uint8_t *PIN, uint8_t pinNum);


#endif