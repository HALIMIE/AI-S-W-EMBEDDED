﻿/*
 * FND.h
 *
 * Created: 2024-12-03 오후 1:09:11
 *  Author: KCCISTC
 */ 


#ifndef FND_H_
#define FND_H_

#define F_CPU 16000000UL
#include <avr/io.h>
#include <util/delay.h>
#include "../../periph/GPIO/GPIO.h"
#define FND_DIGIT_DDR	DDRE
#define FND_DIGIT_PORT	PORTE
#define FND_NUM_DDR		DDRF
#define FND_NUM_PORT	PORTF
#define FND_DIGIT_1		4
#define FND_DIGIT_2		5
#define FND_DIGIT_3		6
#define FND_DIGIT_4		7
#define FND_COLON      10
void COUNTFLOW();
void STOPWATCH();


void FND_dispNum(uint16_t fndNum);

void FND_init();

void FND_setfndData(uint16_t data);

void FND_ISR_Process();

void FND_colonOff();
void FND_colonOn();

#endif /* FND_H_ */