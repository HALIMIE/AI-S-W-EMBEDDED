﻿#include "LED.h"

void Led_init()  //
{
	LedDDR = 0xff;
}

void Led_WriteData(uint8_t data)  //
{
	LedPORT = data;
}
void Led_allOff()  //
{
	LedPORT = 0x00;
}
void Led_allOn()  //
{
	LedPORT = 0xff;
}

void Light_1()
{
	LedPORT = ((1<<0) | (1<<1)); //
}
void Light_2()
{
	LedPORT = ((1<<0) | (1<<1)| (1<<2) | (1<<3)); //
}

void Light_3()
{
	LedPORT = ((1<<0) | (1<<1)| (1<<2) | (1<<3) |(1<<4)|(1<<5)); //
	
}
void Light_4()
{
	LedPORT = ( (1<<0) | (1<<1)| (1<<2) | (1<<3) | (1<<4) |(1<<5)| (1<<6) | (1<<7)); //
}
