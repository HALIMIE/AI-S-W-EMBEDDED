﻿#include "CLOCK.h"

enum{SM, HM, MODIFY};
uint16_t milisec;
uint8_t sec, min, hour;
button_t btnSW, btnMODIFY, btnIH, btnIM;
uint8_t ClockState =SM ;
	
uint16_t SMData;
uint16_t HMData;
	

void Clock_init()
{
	milisec = 0;
	sec = 45;
	min =11;
	hour = 3;
	
	FND_init();
	Button_init(&btnSW,&DDRA,&PINA,0);
	Button_init(&btnMODIFY,&DDRA,&PINA,1);
	Button_init(&btnIH,&DDRA,&PINA,2);
	Button_init(&btnIM,&DDRA,&PINA,3);
	TIM0_OVF_init();
	TIM2_CTC_init();
}

void Clock_incsec()
{

	milisec = (milisec+1)%1000;
	if(milisec<500) FND_colonOn();
	else FND_colonOff();
	
	
	     //1~ 999까지 리턴해서 isr가는데 999+1 0 되면 리턴안하구 밑으로감
	if(milisec) return;
	
	
	sec = (sec+1) % 60;
	if(sec) return;
	
	min = (min+1) % 60;
	if(min) return;
	
	hour = (hour+1) %24;
}

void clock_eventCheck()
{
	
	switch(ClockState)
	{
		case SM :
		if(Button_GetState(&btnSW)==ACT_RELEASED)
		{
			ClockState = HM;
		}
		//else if(Button_GetState(&btnReset)==ACT_RELEASED)
		//{
			//stopWatchState = RESET;
		//}
		break;
		
		case HM :
		if(Button_GetState(&btnSW)==ACT_RELEASED)
		{
			ClockState = SM;
		}
		else if(Button_GetState(&btnMODIFY)==ACT_RELEASED)
		{
			ClockState = MODIFY;
			
		}
		
		break;
		
		
		//stopWatchState = STOP;
	}

}
void Clock_execute()
{

	
	uint16_t Data;
	HMData = (hour*100)+(min);
	SMData = (sec*100)+(milisec/10);   //천자리에 min의 1의 자리를 넣고+백에자리에는  +십 + 일 :::: min의1의자리  sec10 sec1 mili*100
	
	if(ClockState == SM)
	{
		FND_setfndData(SMData);
	
	}

	else if(ClockState == HM)
	{
	  FND_setfndData(HMData);
	}
	else if(ClockState == MODIFY)
	{
		if(Button_GetState(&btnIH)==ACT_RELEASED)
		{
			hour++;
		}
		else if(Button_GetState(&btnIM)==ACT_RELEASED)
		{
			min++;
		}
		else if(Button_GetState(&btnMODIFY)==ACT_RELEASED)
		{
			ClockState = SM;
		}
		FND_setfndData(HMData);
		
	}
	
	
}


void clock_run()
{
	clock_eventCheck();
	Clock_execute();
	
}