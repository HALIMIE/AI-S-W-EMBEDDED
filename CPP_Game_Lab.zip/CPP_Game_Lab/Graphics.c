#include "device_driver.h"
#include "ENG8X16.H"
#include <stdarg.h>
#include <stdio.h>
#include <string.h>

#define ENG_FONT_X 8
#define ENG_FONT_Y 16

#define COPY(A, B)                    \
	for (loop = 0; loop < 32; loop++) \
		*(B + loop) = *(A + loop);
#define OR(A, B)                      \
	for (loop = 0; loop < 32; loop++) \
		*(B + loop) |= *(A + loop);

void Lcd_Eng_Putch(int x, int y, int color, int bkcolor, int data, int zx, int zy)
{
	unsigned offset, loop;
	unsigned char xs, ys;
	unsigned char temp[32];
	unsigned char bitmask[] = {128, 64, 32, 16, 8, 4, 2, 1};

	offset = (unsigned)(data * 16);
	COPY(eng8x16 + offset, temp);

	for (ys = 0; ys < 16; ys++)
	{
		for (xs = 0; xs < 8; xs++)
		{
			if (temp[ys] & bitmask[xs])
			{

				if ((zx == 1) && (zy == 1))
					Lcd_Put_Pixel(x + xs, y + ys, color);
				else if ((zx == 2) && (zy == 1))
				{
					Lcd_Put_Pixel(x + 2 * xs, y + ys, color);
					Lcd_Put_Pixel(x + 2 * xs + 1, y + ys, color);
				}
				else if ((zx == 1) && (zy == 2))
				{
					Lcd_Put_Pixel(x + xs, y + 2 * ys, color);
					Lcd_Put_Pixel(x + xs, y + 2 * ys + 1, color);
				}
				else if ((zx == 2) && (zy == 2))
				{
					Lcd_Put_Pixel(x + 2 * xs, y + 2 * ys + 1, color);
					Lcd_Put_Pixel(x + 2 * xs + 1, y + 2 * ys, color);
					Lcd_Put_Pixel(x + 2 * xs, y + 2 * ys, color);
					Lcd_Put_Pixel(x + 2 * xs + 1, y + 2 * ys + 1, color);
				}
			}
			else
			{
				if ((zx == 1) && (zy == 1))
					Lcd_Put_Pixel(x + xs, y + ys, bkcolor);
				else if ((zx == 2) && (zy == 1))
				{
					Lcd_Put_Pixel(x + 2 * xs, y + ys, bkcolor);
					Lcd_Put_Pixel(x + 2 * xs + 1, y + ys, bkcolor);
				}
				else if ((zx == 1) && (zy == 2))
				{
					Lcd_Put_Pixel(x + xs, y + 2 * ys, bkcolor);
					Lcd_Put_Pixel(x + xs, y + 2 * ys + 1, bkcolor);
				}
				else if ((zx == 2) && (zy == 2))
				{
					Lcd_Put_Pixel(x + 2 * xs, y + 2 * ys + 1, bkcolor);
					Lcd_Put_Pixel(x + 2 * xs + 1, y + 2 * ys, bkcolor);
					Lcd_Put_Pixel(x + 2 * xs, y + 2 * ys, bkcolor);
					Lcd_Put_Pixel(x + 2 * xs + 1, y + 2 * ys + 1, bkcolor);
				}
			}
		}
	}
}

void Lcd_Puts(int x, int y, int color, int bkcolor, const char *str, int zx, int zy)
{
	unsigned data;

	while (*str)
	{
		data = *str++;
		Lcd_Eng_Putch(x, y, color, bkcolor, (int)data, zx, zy);
		x += zx * ENG_FONT_X;
	}
}

void Lcd_Printf(int x, int y, int color, int bkcolor, int zx, int zy, const char *fmt, ...)
{
	va_list ap;
	char string[256];

	va_start(ap, fmt);
	vsprintf(string, fmt, ap);
	Lcd_Puts(x, y, color, bkcolor, string, zx, zy);
	va_end(ap);
}
