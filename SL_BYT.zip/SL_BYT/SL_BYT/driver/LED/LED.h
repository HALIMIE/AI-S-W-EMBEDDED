﻿
#ifndef LED_H_
#define LED_H_

#include <avr/io.h>  //추가
#define F_CPU 16000000UL
#include <util/delay.h>
#include "../../periph/GPIO/GPIO.h"


//#define LedDDR DDRD
//#define LedPORT PORTD

//void Led_init();
void Led_init(volatile uint8_t *DDR);
//void Led_WriteData(uint8_t data);  //
void Led_WriteData(volatile uint8_t *PORT,uint8_t data);


//void Led_allOff() ; 
void Led_allOff(volatile uint8_t *PORT);
//void Led_allOn();
void Led_allOn(volatile uint8_t *PORT); //이러면 저위에 ledDDR , LedPORT지워도됨
void Light_1();

void Light_2();

void Light_3();

void Light_4();




#endif /* LED_H_ */