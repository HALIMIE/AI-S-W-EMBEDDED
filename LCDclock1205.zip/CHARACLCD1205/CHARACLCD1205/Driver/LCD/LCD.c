﻿#include "LCD.h"

uint8_t lcdControlData;

void Gpio_init()
{
	LCD_CONTROL_DDR |= (1<<LCD_RS) | (1<<LCD_RW) | (1<<LCD_E);
	LCD_DATA_DDR |= 0xff;
}


void GPIO_writeControlData(uint8_t data) //portB
{
	LCD_CONTROL_PORT = data;
}

void GPIO_writeData(uint8_t data)
{
	LCD_DATA_PORT = data;
}

void LCD_cmdMode()
{
	//RS->Low로 유지
	lcdControlData &= ~(1<<LCD_RS);
	GPIO_writeControlData(lcdControlData); //다른 비트는 안건들면서 0으로 바꿔주는거
	
}
void LCD_charMode()
{
	//RS->High로 유지
	lcdControlData |= (1<<LCD_RS);
	GPIO_writeControlData(lcdControlData); //다른 비트는 안건들면서 1로 바꿔주는거
}

void LCD_writeMode()
{
	//RW->LOW로 유지
	lcdControlData &= ~(1<<LCD_RW);
	GPIO_writeControlData(lcdControlData) ; //다른 비트는 안건들면서 1로 바꿔주는거
}


void LCD_enableHigh() //E를 High로
{
	lcdControlData |= (1<<LCD_E) ;
	GPIO_writeControlData(lcdControlData);  //PORTB = lcdControlData;
	_delay_ms(1);
}
void LCD_writeByte(uint8_t data)
{
	GPIO_writeData(data);     //PORTC = data;
}
void LCD_enableLow()
{
	lcdControlData &= ~(1<<LCD_E);
	PORTB = lcdControlData;
	_delay_ms(1);  //좀기다려줄게
}

void LCD_writeCmdData(uint8_t data) //LCD 내부 명령어 동작
{
	LCD_cmdMode();      //명령어를 보내는 모드
	LCD_writeMode(); // r/w를 low로 보내야지 write mode
	LCD_enableHigh();  //E 를 high로
	LCD_writeByte(data);       //8개 비트 전달하고
	LCD_enableLow();       //E 를 로우로               이모든건 GPIO를 통해 OuTPUT하는것
	
}

void LCD_writeCharData(uint8_t data) // LCD char 쓰는 동작
{
	LCD_charMode();
	LCD_writeMode();
	LCD_enableHigh();
	LCD_writeByte(data);
	LCD_enableLow();
}

void LCD_writeString(char *str)
{
	for(int i=0; str[i];i++) //i가 0 부터 str가 널만날때까지
	{
		LCD_writeCharData(str[i]);
	}
}
void LCD_init()//LCD에 대한 init 함수
{
	Gpio_init();
	//DDRB = 3
	//DDRC = 8
	//p.12 reset function
	_delay_ms(15);
	//function set (rs0 rw0(writemode) e0) 0 0 1 DL(1) N(1) F(0) -- (dontcare 0) = 0x38 명령어다 data 아님
	LCD_writeCmdData(0x38);	        //instruct mode 로 mcu가 보냈기 때문에 LCD는  function set 이라 여기고
	//LCD_FUNCTION_SET 0x38
	
	_delay_ms(5);					//4.5ms 기다리라했으니깐
	LCD_writeCmdData(0x38);
	_delay_ms(1);				    //마이크로 섹 기다리라했으니까
	LCD_writeCmdData(0x38);
	LCD_writeCmdData(0x38);			// fs 한번더보내고
	//LCD_DISPLAY_OFF 0x08;
	LCD_writeCmdData(0x08);
	LCD_writeCmdData(0x01);
	LCD_writeCmdData(0x06);			//LCD_ENTRYMODE_SET 0000 0 1 1 0
	//초기화 끝
	//위에 display off 가있었으니깐 on 하나 넣어주자
	LCD_writeCmdData(0x0C);		    //LCD_DISPA
}


void LCD_gotoXY(uint8_t row, uint8_t col)
{
	col %= 16, row %=2 ;
	uint8_t lcdregisterAddress = (0x40 * row) + col;
	uint8_t command = 0x80 + lcdregisterAddress;
	LCD_writeCmdData(command);
}

void LCD_writeStringXY(uint8_t row, uint8_t col, char *str)
{
	LCD_gotoXY(row,col);
	LCD_writeString(str);
	
}
