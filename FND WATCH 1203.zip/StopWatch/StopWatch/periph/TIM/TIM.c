﻿/*
 * TIM.c
 *
 * Created: 2024-12-03 오후 3:31:26
 *  Author: KCCISTC
 */ 
#include "TIM.h"



	
	void TIM0_OVF_init()  //1ms 마다 오버플로우
	{
			//timer/counter 0 번에 대한 overflow interrupt 설정
			
			
			//prescaler 1/1024 로 설정하는 방법은 뭘바야하냐 data sheet 보고
			//cs02 (1) cs01 (1)  cs00 (1)
			//TCCR0 |= (0<< CS02) |  (0<<CS01) |(1<<CS00);       //001로하면 너무 빨라서 켜져있는것같아
			TCCR0 |= (1<< CS02) |  (0<<CS01) |(1<<CS00);
			
			//TIMSL 마스크 설정 타이머 오버플로우 인터럽트 인에이블
			TIMSK |= (1<<TOIE0); // 1로 넣어주는 식
			
			TCNT0 = 130; //오버플로우되면 130으로 간다잇
	}