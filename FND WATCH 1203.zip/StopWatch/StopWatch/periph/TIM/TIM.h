﻿/*
 * TIM.h
 *
 * Created: 2024-12-03 오후 3:31:34
 *  Author: KCCISTC
 */ 


#ifndef TIM_H_
#define TIM_H_

#include <avr/io.h>
#define F_CPU 16000000UL
#include <util/delay.h>
void TIM0_OVF_init();



#endif /* TIM_H_ */