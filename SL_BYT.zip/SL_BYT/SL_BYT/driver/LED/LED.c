﻿#include "LED.h"

void Led_init(volatile uint8_t *DDR)  //
{
	 //DDRD = 0xff;
	 //LedDDR = 0xff;
	 Gpio_initPort(DDR, OUTPUT); //어떤 디디알인지, 방향성

}

void Led_WriteData(volatile uint8_t *PORT,uint8_t data)  //
{
	//LedPORT = data;
	Gpio_writePort(PORT,data);
}

void Led_allOff(volatile uint8_t *PORT)  //
{
	//LedPORT = 0x00;
	Gpio_writePort(PORT,0x00);
}

void Led_allOn(volatile uint8_t *PORT)  //
{
	//LedPORT = 0xff;
	Gpio_writePort(PORT,0xff);
}

//void Light_1()
//{
	//PORT = ((1<<0) | (1<<1)); //
//}
//
//void Light_2()
//{
	//LedPORT = ((1<<0) | (1<<1)| (1<<2) | (1<<3)); //
//}
//
//void Light_3()
//{
	//LedPORT = ((1<<0) | (1<<1)| (1<<2) | (1<<3) |(1<<4)|(1<<5)); //
	//
//}
//
//void Light_4()
//{
	//LedPORT = ( (1<<0) | (1<<1)| (1<<2) | (1<<3) | (1<<4) |(1<<5)| (1<<6) | (1<<7)); //
//}
