﻿#include "FNDclock.h"

uint16_t milisec;
uint8_t sec, min, hour;
button_t btnMODE, btnMODIFY, btnIH, btnIM,btnReset;
uint8_t ClockState,timeClockModiState ;

uint16_t SMData;
uint16_t HMData;

void clock_HM()
{
	
	
	
	HMData = (hour*100)+(min);
	SMData = (sec*100)+(milisec/10);
	FND_setfndData(HMData);
	
}
void clock_SM()
{
	
	//if(milisec%100 <50) FND_colonOn();     // :깜빡거리는부분
	//else FND_colonOff();
	
	
	HMData = (hour*100)+(min);
	SMData = (sec*100)+(milisec/10);
	FND_setfndData(SMData);
	
}
void Clock_execute()
{

	
	
	
	switch(ClockState)
	{
		case SM :
		clock_SM();
	
		break;
		
		case HM :
		clock_HM();
	
		break;
		
	}
	
	
	
	
	
}


void Clock_run()
{
	Clock_eventCheck();
	Clock_execute();
	
}