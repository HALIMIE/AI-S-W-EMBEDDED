﻿#include <avr/io.h>  
#define F_CPU 16000000UL
#include <util/delay.h>
#include "../../driver/Button/Button.h"
#include "../../driver/LED/LED.h"
void StandLight_init();
void StandLight_execute();
void StandLight_run();
void StandLight_eventCheck();
enum {LED_OFF,MODE1,MODE2,MODE3,MODE4};
#define LED_PORT PORTD
#define LED_DDR DDRD
#define BUTTON_DDR DDRA
#define BUTTON_PIN PINA

void StandLight_allOff();

void StandLight_MODE1();

void StandLight_MODE2();

void StandLight_MODE3();

void StandLight_MODE4();