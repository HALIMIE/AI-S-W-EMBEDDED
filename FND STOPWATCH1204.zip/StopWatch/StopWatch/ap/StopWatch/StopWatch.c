﻿#include "StopWatch.h"


enum{STOP, RUN, RESET};
uint16_t milisec;
uint8_t sec, min, hour;
button_t btnRunStop, btnReset;
uint8_t stopWatchState = STOP ;

void StopWatch_init()
{
	milisec = 0;
	sec = 0;
	min =0;
	hour = 0;
	
	FND_init();
	Button_init(&btnRunStop,&DDRA,&PINA,0);
	Button_init(&btnReset,&DDRA,&PINA,1);
	TIM0_OVF_init();
	TIM2_CTC_init();
	
}

void StopWatch_incMilisec()
{
	if(stopWatchState == RUN )
	{
	milisec = (milisec+1) % 1000 ;     //1~ 999까지 리턴해서 isr가는데 999+1 0 되면 리턴안하구 밑으로감
	}
	else return;
	
	if(milisec) return;
	
	sec = (sec+1) % 60;
	if(sec) return;
	
	min = (min+1) % 60;
	if(min) return;
	
	hour = (hour+1) %24;
	
	
}

void StopWatch_run()
{
	
	StopWatch_eventCheck();
	StopWatch_execute();
	
    

    

	

}

void StopWatch_eventCheck()
{
	
	switch(stopWatchState)
	{
		case STOP :
		if(Button_GetState((&btnRunStop))==ACT_RELEASED)
		{
			stopWatchState = RUN;
		}
		else if(Button_GetState(&btnReset)==ACT_RELEASED)
		{
			stopWatchState = RESET;
		}
		break;
		
		case RUN :
		if(Button_GetState((&btnRunStop))==ACT_RELEASED)
		{
			stopWatchState = STOP;
		}
		
		break;
		
		case RESET :
		stopWatchState = STOP;
	}

}
void StopWatch_execute()
{
	uint16_t stopWatchData;
	static int16_t prevTime = 0;
	
	if(stopWatchState == RESET)
	{
			milisec = 0;
			sec = 0;
			min =0;
			hour = 0;
	}
	stopWatchData = (min%10*1000)+(sec*10)+(milisec/100%10);   //천자리에 min의 1의 자리를 넣고+백에자리에는  +십 + 일 :::: min의1의자리  sec10 sec1 mili*100

	FND_setfndData(stopWatchData); //동기화 함수
}