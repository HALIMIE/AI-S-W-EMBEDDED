﻿#include "Button.h" //사용자 헤더파일 

void Button_init(button_t *btn, volatile uint8_t *ddr, volatile uint8_t *pin, uint8_t pinNum) //매개변수 4개함수
{
	btn->DDR = ddr;
	btn->PIN = pin;
	btn->pinNum = pinNum;
	btn->prevState = RELEASED;
	*btn->DDR &= ~(1<<btn->pinNum);
	
}


uint8_t Button_GetState(button_t *btn)   // 범용함수로 만들떄는 버튼두ㅣ 숫자 지운다
{
	
	//static uint8_t prevState = 1;   //1로 정적변수, 구조체 부분에서는 삭제한다 이줄을  이미 이닛에서 릴리즈드로 바꿔놨으니깐
	
	uint8_t curState = (*btn->PIN & (1<<btn->pinNum)); //
	
	if((curState == PUSHED) && (btn->prevState ==RELEASED))
	{
		_delay_ms(10);
		btn->prevState = PUSHED;
		return ACT_PUSHED;
	}
	
	else if ((curState !=PUSHED) && (btn->prevState == PUSHED))
	{
		
		_delay_ms(10);
		btn->prevState = RELEASED;
		return ACT_RELEASED;
	}
	return ACT_NONE;
}