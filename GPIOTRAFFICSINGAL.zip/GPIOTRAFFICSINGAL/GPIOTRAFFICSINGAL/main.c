
//#define F_CPU 16000000UL
//#include <avr/io.h>
//#include <util/delay.h>
//
//#define trafficButtonDDR DDRA
//#define trafficButtonPIN PINA
//#define trafficLedDDR DDRF
//#define trafficLedPORT PORTF
//#define B_AUTO			0
//#define B_MANUAL		1
//#define B_SWITCHING		2
//enum{AUTO,MANUAL};
//enum{RED_GREEN, RED_YELLOW,GREEN_RED,YELLOW_RED};
//uint8_t trafficState;
//void TrafficSignal_Auto();
//void TrafficSignal_Manual();
//void TrafficSignal_RedGreen();
//void TrafficSignal_RedYellow();
//void TrafficSignal_GreenRed();
//void TrafficSignal_YellowRed();
	//
//uint32_t timeTick = 0;
//
//
	//
//
//int main(void)
//{
	//DDRA = 0x00;
	//DDRF = 0xff;
	//uint8_t ledData=0x01;
	//
	//trafficButtonDDR &= ~((1<<B_AUTO) |(1<<B_MANUAL) | (1<< B_SWITCHING));
	//trafficLedDDR |= ((1<<0)|(1<<1)|(1<<2)|(1<<3)|(1<<4)|(1<<5));
	//uint8_t trafficModeState = AUTO;
	//trafficState = RED_GREEN;
	//while(1)
	//{
		//if((trafficButtonPIN & (1<<B_AUTO)) == 0)  //버튼눌렸는지 체크 오토모드 인지 메뉴얼 모드인지
		//{
			//trafficModeState = AUTO;
		//}
		//else if((trafficButtonPIN & (1<<B_MANUAL)) == 0)
		//{
			//trafficModeState = MANUAL;
		//}
		//
		////모드러닝 눌리든말든 스위치 실행
		//
		//switch(trafficModeState)
		//{
			//
		//
		//case AUTO:
		//TrafficSignal_Auto();
		//break;
		//case MANUAL:
		//TrafficSignal_Manual();
		//break;
		//}
		//_delay_ms(1);
		//timeTick++;
		//
	//}
	//
	//
//}
//void TrafficSignal_Auto()  //첨에 이함수 호출
//{
	//
	//static uint32_t prevTime = 0; // 딜레이 막아보자
	//switch (trafficState) // 트래픽 스테이트에 따라서 스위치문 또 실행
	//{
		//case RED_GREEN:
		//TrafficSignal_RedGreen();
		////_delay_ms(3000); //수동일떄는 지우고  if문
		////if((trafficButtonPIN & (1<<B_SWITCHING))==0)
		//
		////delay 지우고 프면 timetick은플플플플계속 올라가는거 prevtime은 
		////
		//if(timeTick - prevTime >=3000)    //이 조건시 prevtime은 0이니깐 타임틱이 3000될떄까지는 계속이프문 안들어가다
		//{
			//prevTime = timeTick ;            //3000넘으면 
			//trafficState = RED_YELLOW;
			//
		//}
	//
		//break;
		//
		//
		//case RED_YELLOW:
		//TrafficSignal_RedYellow();
		////_delay_ms(1000);
		//if(timeTick - prevTime >=1000)
		//{
			//prevTime = timeTick ;  //4000을 넣고 프리브타임에
			//trafficState = GREEN_RED;  //상태변환
			//
		//}
		//
		//break;
		//case GREEN_RED:
		//TrafficSignal_GreenRed();
		////_delay_ms(3000);
		//
				//if(timeTick - prevTime >=3000)
				//{
					//prevTime = timeTick ;  //4000을 넣고 프리브타임에
					//trafficState = YELLOW_RED;  //상태변환
					//
				//}
		//break;
		//case YELLOW_RED:
		//TrafficSignal_YellowRed();
		////_delay_ms(1000);
			//if(timeTick - prevTime >=1000)
			//{
				//prevTime = timeTick ;  //4000을 넣고 프리브타임에
				//trafficState = RED_GREEN;  //상태변환
				//
			//}
		//
		//break;
		//
	//}
//}
//void TrafficSignal_Manual()
//{
	//switch (trafficState)
	//{
		//case RED_GREEN:
		//TrafficSignal_RedGreen();
		////_delay_ms(3000); 
		//if((trafficButtonPIN & (1<<B_SWITCHING))==0)
		//{
			//trafficState = RED_YELLOW;
			//
		//}
		//
		//
		//break;
		//case RED_YELLOW:
		//TrafficSignal_RedYellow();
		////_delay_ms(1000);
		//if((trafficButtonPIN & (1<<B_SWITCHING))==0)
		//{
		//trafficState = GREEN_RED;
		//}
		//break;
		//case GREEN_RED:
		//TrafficSignal_GreenRed();
		////_delay_ms(1000);
		//if((trafficButtonPIN & (1<<B_SWITCHING))==0)
		//{
		//trafficState = YELLOW_RED;
		//}
		//break;
		//case YELLOW_RED:
		//TrafficSignal_YellowRed();
		//
		////_delay_ms(1000);
		//if((trafficButtonPIN & (1<<B_SWITCHING))==0)
		//{
		//trafficState = RED_GREEN;
		//}
		//break;
		//
	//}
	//
//}
	//void TrafficSignal_RedGreen()
	//{
		//trafficLedPORT = ((1<<0) | (1<<3)); //
	//}
	//void TrafficSignal_RedYellow()
	//{
		//trafficLedPORT = ((1<<0) | (1<<4)); //
	//}
	//
	//void TrafficSignal_GreenRed()
	//{
		//trafficLedPORT = ((1<<2) | (1<<5)); //
		//
	//}
	//void TrafficSignal_YellowRed()
	//{
		//trafficLedPORT = ((1<<1) | (1<<5)); //
	//}
	//
	
	
	#define F_CPU 16000000UL
	#include <avr/io.h>
	#include <util/delay.h>
	#include "TSap/TrafficSignal/TrafficSignal.h"

	//#define trafficButtonDDR DDRA    //버튼부분에서 핸들링하니깐 제외
	//#define trafficButtonPIN PINA
	
	//#define trafficLedDDR DDRF       
	//#define trafficLedPORT PORTF
	
	//#define B_AUTO			0
	//#define B_MANUAL			1
	//#define B_SWITCHING		2
	//enum{AUTO,MANUAL};
	//enum{RED_GREEN, RED_YELLOW,GREEN_RED,YELLOW_RED};
	//uint8_t trafficState;                          //요부분 ts.h로 보냈음
	
	
	//void TrafficSignal_Auto();
	//void TrafficSignal_Manual();
	//void TrafficSignal_RedGreen();
	//void TrafficSignal_RedYellow();
	//void TrafficSignal_GreenRed();
	//void TrafficSignal_YellowRed();
	//
	//uint32_t timeTick = 0;


	

	//int main(void)
	//{
		//DDRA = 0x00;
		//DDRF = 0xff;
		// uint8_t ledData=0x01;
		
		//trafficButtonDDR &= ~((1<<B_AUTO) |(1<<B_MANUAL) | (1<< B_SWITCHING));
		//trafficLedDDR |= ((1<<0)|(1<<1)|(1<<2)|(1<<3)|(1<<4)|(1<<5));
		//uint8_t trafficModeState = AUTO;
		//trafficState = RED_GREEN;
		//while(1)
		//{
			//if((trafficButtonPIN & (1<<B_AUTO)) == 0)  //버튼눌렸는지 체크 오토모드 인지 메뉴얼 모드인지
			//{
				//trafficModeState = AUTO;
			//}
			//else if((trafficButtonPIN & (1<<B_MANUAL)) == 0)
			//{
				//trafficModeState = MANUAL;
			//}
			//
			////모드러닝 눌리든말든 스위치 실행
			//
			//switch(trafficModeState)
			//{
				//
				//
				//case AUTO:
				//TrafficSignal_Auto();
				//break;
				//case MANUAL:
				//TrafficSignal_Manual();
				//break;
			//}
			//_delay_ms(1);
			//timeTick++;
			
		//}
		
		
	//}
	//void TrafficSignal_Auto()  //첨에 이함수 호출
	//{
		//
		//static uint32_t prevTime = 0; // 딜레이 막아보자
		//switch (trafficState) // 트래픽 스테이트에 따라서 스위치문 또 실행
		//{
			//case RED_GREEN:
			//TrafficSignal_RedGreen();
			////_delay_ms(3000); //수동일떄는 지우고  if문
			////if((trafficButtonPIN & (1<<B_SWITCHING))==0)
			//
			////delay 지우고 프면 timetick은플플플플계속 올라가는거 prevtime은
			////
			//if(timeTick - prevTime >=3000)    //이 조건시 prevtime은 0이니깐 타임틱이 3000될떄까지는 계속이프문 안들어가다
			//{
				//prevTime = timeTick ;            //3000넘으면
				//trafficState = RED_YELLOW;
				//
			//}
			//
			//break;
			//
			//
			//case RED_YELLOW:
			//TrafficSignal_RedYellow();
			////_delay_ms(1000);
			//if(timeTick - prevTime >=1000)
			//{
				//prevTime = timeTick ;  //4000을 넣고 프리브타임에
				//trafficState = GREEN_RED;  //상태변환
				//
			//}
			//
			//break;
			//case GREEN_RED:
			//TrafficSignal_GreenRed();
			////_delay_ms(3000);
			//
			//if(timeTick - prevTime >=3000)
			//{
				//prevTime = timeTick ;  //4000을 넣고 프리브타임에
				//trafficState = YELLOW_RED;  //상태변환
				//
			//}
			//break;
			//case YELLOW_RED:
			//TrafficSignal_YellowRed();
			////_delay_ms(1000);
			//if(timeTick - prevTime >=1000)
			//{
				//prevTime = timeTick ;  //4000을 넣고 프리브타임에
				//trafficState = RED_GREEN;  //상태변환
				//
			//}
			//
			//break;
			//
		//}
	//}
	//void TrafficSignal_Manual()
	//{
		//switch (trafficState)
		//{
			//case RED_GREEN:
			//TrafficSignal_RedGreen();
			////_delay_ms(3000);
			//if((trafficButtonPIN & (1<<B_SWITCHING))==0)
			//{
				//trafficState = RED_YELLOW;
				//
			//}
			//
			//
			//break;
			//case RED_YELLOW:
			//TrafficSignal_RedYellow();
			////_delay_ms(1000);
			//if((trafficButtonPIN & (1<<B_SWITCHING))==0)
			//{
				//trafficState = GREEN_RED;
			//}
			//break;
			//case GREEN_RED:
			//TrafficSignal_GreenRed();
			////_delay_ms(1000);
			//if((trafficButtonPIN & (1<<B_SWITCHING))==0)
			//{
				//trafficState = YELLOW_RED;
			//}
			//break;
			//case YELLOW_RED:
			//TrafficSignal_YellowRed();
			//
			////_delay_ms(1000);
			//if((trafficButtonPIN & (1<<B_SWITCHING))==0)
			//{
				//trafficState = RED_GREEN;
			//}
			//break;
			//
		//}
		//
	//}
	
	//tsled 폴더로 보내버렸다
	//void TrafficSignal_RedGreen()
	//{
		//trafficLedPORT = ((1<<0) | (1<<3)); //
	//}
	//void TrafficSignal_RedYellow()
	//{
		//trafficLedPORT = ((1<<0) | (1<<4)); //
	//}
	//
	//void TrafficSignal_GreenRed()
	//{
		//trafficLedPORT = ((1<<2) | (1<<5)); //
		//
	//}
	//void TrafficSignal_YellowRed()
	//{
		//trafficLedPORT = ((1<<1) | (1<<5)); //
	//}
	//
	
	//
	int main(void)
	{
		
		TrafficSignal_init();
		
		while(1)
		{
			TrafficSignal_execute();
		}
	}