﻿#include "GPIO.h"


//GPIO 기능

//init - port에 대한 init (8EA or 5EA)

void Gpio_initPort(volatile uint8_t *DDR, uint8_t dir)  //8개를 한꺼번에 초기화 DDR 어떤 디디알 dir 방향
{
	
	//DDRD = 0xff;
	//DDRA = 0x00;
	
	if(dir == OUTPUT)
	{
		*DDR = 0xff;
	}
	
	else
	{
		*DDR = 0x00;
	}
	
	
}

//init - pin에 대한 init (1EA)
void Gpio_initPin(volatile uint8_t *DDR, uint8_t pinNum , uint8_t dir) //pinNum은 몇번째 핀인지 1개 핀에 대한 초기화
{
	
	if(dir == OUTPUT)
	{
		*DDR |= (1<<pinNum);
	}
	
	else
	{
		*DDR &= ~(1<<pinNum);
	}
	
}


//output - port 8EA 
void Gpio_writePort(volatile uint8_t *PORT, uint8_t data) //어떤 포트를 쓸껀지에대한함수 , 매개변수는 주소값에 대한 포인터 변수 와 어떤 값을 대입하고 싶은지write 값
{
	//PORTD=0xff;
	//PORTC==0xfo
	
	*PORT = data;
	
}


//output - pin 1EA

void Gpio_writePin(volatile uint8_t *PORT, uint8_t pinNum, uint8_t state) // 마지막 state 매개변수는 0 올 1 출력하는변수 
{
	//예를들어 PORTD |= (1<<4) , PORTC &= ~(1<<3) 이런거 하는 함수
	if(state == GPIO_SET)
	{	
	 *PORT |= (1<<pinNum);  //포트에이부터 ~ 에프까지 모든 레지스터에 대해
	}
	else 
	 *PORT &= ~(1<<pinNum);
	
	
}

//input - port 8EA 
uint8_t Gpio_readPort(volatile uint8_t *PIN) //8개의 핀을 한꺼번에 읽어 드린다 uint8_t buttonState; buttonState = PINA;
{                        //return type == uint8_t not void
	return *PIN;         //* 붙여야지 PIN 은 주소 값 만 받고 있으니깐
}


//input - pin 1EA 
uint8_t Gpio_readPin(volatile uint8_t *PIN, uint8_t pinNum ) //return not void  uint8_t  어떤 핀레지스터인지 , 몇번쨰 핀인지 두개에 대한 매개변수
{					
	
	// return 0 or 1 인데
	//예를들어 
	//uint8_t buttonState;
	// buttonState = PINA & (1<<0)  이런 값이 0or1이니깐
	//              (xxxx xxx0 & 0000 0001) != 0  거짓 전체식이 0이됨
	
	return ((*PIN & (1<<pinNum)) !=0	); // 우리 하드웨어 기준으로 누르면 0 떼면 1 PUSHED 0 RELEASED 1
	 //PINA & (1<<0)  이런 값이 0or1이니깐
	 //              (xxxx xxx0 & 0000 0001) != 0  거짓 전체식이 0이됨
	
	
}