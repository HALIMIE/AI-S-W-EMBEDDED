﻿
#ifndef LED_H_
#define LED_H_

#include <avr/io.h>  //추가
#define F_CPU 16000000UL
#include <util/delay.h>


#define LedDDR DDRD
#define LedPORT PORTD

void Led_init();

void Led_WriteData(uint8_t data);  //

void Led_allOff() ; 

void Led_allOn();

void Light_1();

void Light_2();

void Light_3();

void Light_4();




#endif /* LED_H_ */