#include "tab1socketclient.h"
#include "ui_tab1socketclient.h"

Tab1SocketClient::Tab1SocketClient(QWidget *parent) :
    QWidget(parent),
    ui(new Ui::Tab1SocketClient)
{
    ui->setupUi(this);
    ui->pPBSendButton->setEnabled(false);
    pSocketClient = new SocketClient(this);
    connect(pSocketClient,SIGNAL(sigSocketRecv(QString)),this, SLOT(slotRecvUpdate(QString)));

}

Tab1SocketClient::~Tab1SocketClient()
{
    delete ui;
}

void Tab1SocketClient::on_pPBServerConnect_clicked(bool checked)
{
    bool bOk;
    if(checked)
    {
        pSocketClient->slotConnectToServer(bOk);
        if(bOk)
        {
            ui->pPBServerConnect->setText("서버 해제");
            ui->pPBSendButton->setEnabled(true);
        }
    }
    else
    {
        pSocketClient->slotClosedByServer();
        ui->pPBServerConnect->setText("서버 연결");
        ui->pPBSendButton->setEnabled(false);
    }
}

void Tab1SocketClient::slotRecvUpdate(QString strRecvData)
{
    QTime time = QTime::currentTime();
    QString strTime = time.toString();

    strRecvData.chop(1);    //'\n' 제거

    strTime = strTime  + " " + strRecvData;
    ui->pTERecvData->append(strTime);
    strRecvData.replace("[","@");
    strRecvData.replace("]","@");
    QStringList qList = strRecvData.split("@");
    //[KSH_LIN]LED@0x0f ==> @KSH_LIN@LED@0x0f
    //qList[0] => Null, qList[1] => KSH_LIN, qList[2] =>LED, qList[3] => 0x0f

    if((qList[2].indexOf("LAMP")!=-1) || qList[2].indexOf("GAS")!=-1)
    {
            emit tab3RecvDataSig(strRecvData);
    }
    else if((qList[2].indexOf("SENSOR")!=-1))
    {
//            qDebug() << strRecvData;
            emit tab4RecvDataSig(strRecvData);
            emit tab5RecvDataSig(strRecvData);
    }
}
void Tab1SocketClient::on_pPBSendButton_clicked()
{
    QString strRecvId = ui->pLERecvId->text();
    QString strSendData = ui->pLESendData->text();
    if(!strSendData.isEmpty())
    {
        if(strRecvId.isEmpty())
            strSendData = "[ALLMSG]"+strSendData;
        else
            strSendData = "["+strRecvId+"]"+strSendData;
        pSocketClient->slotSocketSendData(strSendData);
        ui->pLESendData->clear();
    }
}
