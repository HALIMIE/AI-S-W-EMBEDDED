#include "mainwidget.h"
#include "ui_mainwidget.h"

MainWidget::MainWidget(QWidget *parent)
    : QWidget(parent)
    , ui(new Ui::MainWidget)
{
    ui->setupUi(this);
    pTab1SocketClient = new Tab1SocketClient(ui->pTab1);
    ui->pTab1->setLayout(pTab1SocketClient->layout());

    pTab3ControlPannel = new Tab3ControlPannel(ui->pTab3);
    ui->pTab3->setLayout(pTab3ControlPannel->layout());

    pTab4ChartPlot = new Tab4ChartPlot(ui->pTab4);
    ui->pTab4->setLayout(pTab4ChartPlot->layout());

    pTab5Database = new Tab5Database(ui->pTab5);
    ui->pTab5->setLayout(pTab5Database->layout());

    ui->tabWidget->setCurrentIndex(2);


    connect(pTab3ControlPannel,SIGNAL(socketSendDataSig(QString)),pTab1SocketClient->pSocketClient,SLOT(slotSocketSendData(QString)));
    connect(pTab1SocketClient,SIGNAL(tab3RecvDataSig(QString)), pTab3ControlPannel,SLOT(tab3RecvDataSlot(QString)));
    connect(pTab1SocketClient, SIGNAL(tab4RecvDataSig(QString)),pTab4ChartPlot,SLOT(Tab4RecvDataSlot(QString)));
    connect(pTab1SocketClient, SIGNAL(tab5RecvDataSig(QString)),pTab5Database,SLOT(Tab5RecvDataSlot(QString)));
}

MainWidget::~MainWidget()
{
    delete ui;
}

