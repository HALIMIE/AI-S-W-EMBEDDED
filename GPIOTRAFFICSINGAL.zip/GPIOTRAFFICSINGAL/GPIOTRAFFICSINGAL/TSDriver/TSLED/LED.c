﻿#include "LED.h"

void Led_init()  //
{
	trafficLedDDR = 0xff;
}

void Led_WriteData(uint8_t data)  //
{
	trafficLedPORT = data;
}
void Led_allOff()  //
{
	trafficLedPORT = 0x00;
}
void Led_allOn()  //
{
	trafficLedPORT = 0xff;
}

void TrafficSignal_RedGreen()
{
	trafficLedPORT = ((1<<0) | (1<<3)); //
}
void TrafficSignal_RedYellow()
{
	trafficLedPORT = ((1<<0) | (1<<4)); //
}

void TrafficSignal_GreenRed()
{
	trafficLedPORT = ((1<<2) | (1<<5)); //
	
}
void TrafficSignal_YellowRed()
{
	trafficLedPORT = ((1<<1) | (1<<5)); //
}
