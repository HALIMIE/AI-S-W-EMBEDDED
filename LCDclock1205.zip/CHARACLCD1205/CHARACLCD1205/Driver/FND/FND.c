﻿/*
 * FND.c
 *
 * Created: 2024-12-03 오후 1:08:56
 *  Author: KCCISTC
 */ 
#include "FND.h"

uint16_t fndData = 0 ;
uint8_t fndColonFlag;


void FND_dispNum(uint16_t fndNum)
{
	//uint8_t fndFont[11] = {0x3f,0x06,0x5b,0x4f,0x66,0x6d,0x7d,0x07,0x7f,0x67} ;
	uint8_t fndFont[11] = {0x3f,0x06,0x5b,0x4f,0x66,0x6d,0x7d,0x07,0x7f,0x67, 0x80} ;
	
	static uint8_t fndDigitState = 0;
	//fndDigitState = (fndDigitState + 1) % 4;
	fndDigitState = (fndDigitState + 1) % 5;
	
	
	FND_DIGIT_PORT |= ( (1<<7) | (1<<6) | (1<<5) | (1<<4) ); //한번 모든 불을 끈다 1이 들어오면 꺼지니 캐소드타입
	
	switch (fndDigitState)
	{
		case 0:
		FND_NUM_PORT = fndFont[fndNum/1000%10];
		FND_DIGIT_PORT &= ~(1<<FND_DIGIT_1);        //PORTE &= ~(1<<4);
		break;
		
		case 1:
		FND_NUM_PORT = fndFont[fndNum/100%10];
		FND_DIGIT_PORT &= ~(1<<FND_DIGIT_2);
		break;
		
		case 2:
		FND_NUM_PORT = fndFont[fndNum/10%10];
		FND_DIGIT_PORT &= ~(1<<FND_DIGIT_3);
		break;
		
		case 3:
		FND_NUM_PORT = fndFont[fndNum%10];
		FND_DIGIT_PORT &= ~(1<<FND_DIGIT_4);
		break;
		
		case 4:
		if(fndColonFlag) FND_NUM_PORT = fndFont[FND_COLON];
		else FND_NUM_PORT = 0x00;
		
		//	FND_NUM_PORT = fndFont[10];   //DP
			FND_DIGIT_PORT &= ~(1<<FND_DIGIT_2);
		break;
		
		
	}
	
}
	
	void FND_init()    //FND 초기화
	{
		
		FND_DIGIT_DDR = 0xff; //DDRE
		
		FND_NUM_DDR = 0xff;		//DDRF
	}
	
	void FND_setfndData(uint16_t data)
	{
		fndData = data;
	}
	
	void FND_ISR_Process()
	{
		FND_dispNum(fndData);
	}
	void FND_colonOn()
	{
		fndColonFlag = 1;
		
	}
	void FND_colonOff()
	{
		fndColonFlag =0;
	}
	
