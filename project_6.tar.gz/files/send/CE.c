#include <stdio.h>

int main()
{
    int x;
    assert(1 == 2);
    scanf("%d", &x);
    printf("%d", x);
    return 0;
}