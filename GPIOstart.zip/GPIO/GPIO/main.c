/*
 * GPIO.c
 *
 * Created: 2024-11-21 오후 3:35:48
 * Author : KCCISTC
 */ 
#define F_CPU 160000UL
#include <avr/io.h>
#include <util/delay.h>


int main(void)
{
    /* Replace with your application code */
	DDRD = 0xff;
	
    while (1) 
    {
		PORTD = 0xff;
		_delay_ms(200);
		PORTD = 0x00;
		_delay_ms(200);
    }
}

