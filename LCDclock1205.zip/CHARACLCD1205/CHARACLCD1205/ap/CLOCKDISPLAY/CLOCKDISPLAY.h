﻿


#ifndef CLOCKDISPLAY_H_
#define CLOCKDISPLAY_H_
#include <avr/io.h>
#define F_CPU 16000000UL
#include <util/delay.h>
#include "../../Driver/BUTTON/button.h"
#include "../../Driver/FND/FND.h"
#include "../../periph/GPIO/GPIO.h"
#include "../../periph/TIM/TIM.h"
#include "../../common/TimeTick/TimeTick.h"



#endif /* CLOCKDISPLAY_H_ */