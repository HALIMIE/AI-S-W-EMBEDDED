﻿/*
 * StopWatch.h
 *
 * Created: 2024-12-04 오전 10:38:42
 *  Author: KCCISTC
 */ 


#ifndef STOPWATCH_H_
#define STOPWATCH_H_
#include <avr/io.h>
#define F_CPU 16000000UL
#include <util/delay.h>
#include "../../Driver/BUTTON/button.h"
#include "../../Driver/FND/FND.h"
#include "../../periph/GPIO/GPIO.h"
#include "../../periph/TIM/TIM.h"
#include "../../common/TimeTick/TimeTick.h"
void StopWatch_run();
void StopWatch_init();
void StopWatch_incMilisec();
void StopWatch_eventCheck();
void StopWatch_execute();




#endif /* STOPWATCH_H_ */