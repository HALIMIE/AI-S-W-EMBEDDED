﻿/*
 * TimeTick.h
 *
 * Created: 2024-12-03 오후 3:38:17
 *  Author: KCCISTC
 */ 


#ifndef TIMETICK_H_
#define TIMETICK_H_
#include <avr/io.h>  //추가
#define F_CPU 16000000UL
#include <util/delay.h>
#include "../../periph/GPIO/GPIO.h"

void incTick();


void clearTick();

uint32_t getTick();




#endif /* TIMETICK_H_ */