
#define F_CPU 16000000UL
#include <avr/io.h>
#include <util/delay.h>
#include "AP/SL/SL.h"


	int main(void)
	{
		
		SL_init();
		
		while(1)
		{
			SL_execute();
		}
	}