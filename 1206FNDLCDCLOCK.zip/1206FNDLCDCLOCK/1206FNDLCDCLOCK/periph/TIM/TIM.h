﻿

#ifndef TIM_H_
#define TIM_H_

#include <avr/io.h>
#define F_CPU 16000000UL
#include <util/delay.h>
void TIM0_OVF_init();
void TIM2_CTC_init();



#endif /* TIM_H_ */