﻿/*
 * LedMachine.h
 *
 * Created: 2024-11-26 오전 11:29:47
 *  Author: KCCISTC
 */ 


#ifndef LEDMACHINE_H_
#define LEDMACHINE_H_

#define F_CPU 16000000UL
#include <avr/io.h>  //추가

#include <util/delay.h>

#include "../../driver/Button/Button.h" 
#include "../../driver/LED/LED.h"  //은상위폴더 한칸씩


//
//#define LED_DDR DDRD
//#define LED_PORT PORTD

enum {LED1,LED2,LED3,LED4};
	
void Led1_blink();
void Led2_blink();
void Led3_blink();
void Led4_blink();

	//led 머신헤더에서 메인에서 쓰는 함수선언 
	
void LedMachine_init();
void LedMachine_execute();
	