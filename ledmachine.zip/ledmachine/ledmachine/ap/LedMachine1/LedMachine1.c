﻿#include "LedMachine1.h"

uint8_t ledData;

uint8_t ledState;

button_t btnNext, btnPrev; //전역변수 설정해놓는다
	
void Led1_blink()
{
	ledData ^= 0x01;
	//PORTD = ledData;                 //portd 를 썼다는건 엘이디 드라이버가없는거
	Led_WriteData(ledData); //를써보겠다. 
}

void Led2_blink()
{
	ledData ^= 0x02;
	//PORTD = ledData;
	Led_WriteData(ledData);
}
void Led3_blink()
{
	ledData ^= 0x04;
	//PORTD = ledData;
	Led_WriteData(ledData);
}
void Led4_blink()
{
	ledData ^= 0x08;
	//PORTD = ledData;
	Led_WriteData(ledData);
}

	
	void LedMachine_init()
	{
		
	// LED_DDR=0xff;    //디디알 초기화 대신밑에줄
	Led_init();
	
	// BUTTON_DDR &= ~((1<<BUTTON_NEXT)|(1<<BUTTON_PREV)); 
	
	ledData = 0x01;
	
	ledState = LED1; //초기화
	
	//button_t btnNext, btnPrev; //메인함수에서 btnnext, btnprev 구조체 변수 두개 선언한거임
	
	Button_init(&btnNext, &DDRA, &PINA, 0);        //*btn에 &btnnext 들어가고 별디디알에 &디디알에이 들어가고 ...
	Button_init(&btnPrev, &DDRA, &PINA, 1);
	
	}
	
	void LedMachine_execute()
	{
		switch(ledState)
		{
			case LED1 :
			Led1_blink();
			if(Button_GetState(&btnNext) == ACT_RELEASED)  //1아니면 0 이 리턴되는 함수
			{
				ledState = LED2;
				ledData=0x00;
			}
			else if(Button_GetState(&btnPrev) == ACT_RELEASED)                    //(!(PINA & (1<<1)))
			{
				ledState = LED4;
				ledData=0x00;
			}
			break;
			
			case LED2 :
			Led2_blink();
			if(Button_GetState(&btnNext) == ACT_RELEASED)      //if(!(PINA & (1<<0)))
			{
				ledState = LED3;
				ledData=0x00;
			}
			else if(Button_GetState(&btnPrev) == ACT_RELEASED) //(!(PINA & (1<<1)))
			{
				ledState = LED1;
				ledData=0x00;
			}
			break;
			
			case LED3 :
			Led3_blink();
			if(Button_GetState(&btnNext)==ACT_RELEASED) //(!(PINA & (1<<0)))
			{
				ledState = LED4;
				ledData=0x00;
			}
			else if(Button_GetState(&btnPrev) == ACT_RELEASED)  //(!(PINA & (1<<1)))
			{
				ledState = LED2;
				ledData=0x00;
			}
			break;
			
			case LED4 :
			Led4_blink();
			if(Button_GetState(&btnNext) == ACT_RELEASED)          //(!(PINA & (1<<0)))
			{
				ledState = LED1;
				ledData=0x00;
			}
			else if(Button_GetState(&btnPrev) == ACT_RELEASED)    // (!(PINA & (1<<1)))
			{
				ledState = LED3;
				ledData=0x00;
			}
			break;
			
		}
		_delay_ms(200);
	}
	
	
	
	
		