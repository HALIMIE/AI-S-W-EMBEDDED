﻿#include "LCD.h"

uint8_t lcdControlData;



void Gpio_init()  
{
	Gpio_initPin(&LCD_CONTROL_DDR,LCD_RS,OUTPUT);
	Gpio_initPin(&LCD_CONTROL_DDR,LCD_RW,OUTPUT);
	Gpio_initPin(&LCD_CONTROL_DDR,LCD_E,OUTPUT);
	Gpio_initPort(&LCD_DATA_DDR, OUTPUT);  //위 네줄과 아래 두줄이 같은의미
	
	
	//LCD_CONTROL_DDR |= (1<<LCD_RS) | (1<<LCD_RW) | (1<<LCD_E);
	//LCD_DATA_DDR |= 0xff;
}


void GPIO_writeControlData(uint8_t data) //portB
{
	LCD_CONTROL_PORT = data;
}

void GPIO_writeData(uint8_t data)
{
	LCD_DATA_PORT = data;
}

void LCD_cmdMode()
{
	
	//RS->Low로 유지 RS bit 0
	// Gpio_writePin(&PORTB,5,0); //하나의 핀에 특정값넣는 핀의 주소값, 아래와 같은 의미
	Gpio_writePin(&LCD_CONTROL_PORT,LCD_RS,GPIO_RESET); // 이거 하나로 대체 가능 
	
	//lcdControlData &= ~(1<<LCD_RS);
	//GPIO_writeControlData(lcdControlData); //다른 비트는 안건들면서 0으로 바꿔주는거
	
}
void LCD_charMode()
{
	//RS->High로 유지
	
	Gpio_writePin(&LCD_CONTROL_PORT,LCD_RS,GPIO_SET);
	
	//lcdControlData |= (1<<LCD_RS);
	//GPIO_writeControlData(lcdControlData); //다른 비트는 안건들면서 1로 바꿔주는거
}

void LCD_writeMode()
{
	//RW->LOW로 유지
	Gpio_writePin(&LCD_CONTROL_PORT,LCD_RW,GPIO_RESET);
	//lcdControlData &= ~(1<<LCD_RW);
	//GPIO_writeControlData(lcdControlData) ; //다른 비트는 안건들면서 1로 바꿔주는거
}


void LCD_enableHigh() //E를 High로
{
	
	Gpio_writePin(&LCD_CONTROL_PORT,LCD_E,GPIO_SET); //밑 단 두세줄과 같은 의미
	_delay_ms(1); //현재 사용 하드웨어 특성상 1ms 기다려주는 딜레이
	
	//lcdControlData |= (1<<LCD_E) ;
	//GPIO_writeControlData(lcdControlData);  //PORTB = lcdControlData;
	//_delay_ms(1);
}

void LCD_enableLow()
{
	Gpio_writePin(&LCD_CONTROL_PORT,LCD_E,GPIO_RESET);
	_delay_ms(1);
	
	
	//lcdControlData &= ~(1<<LCD_E);
	//PORTB = lcdControlData;
	//_delay_ms(1);  //좀기다려줄게
}


void LCD_writeByte(uint8_t data)
{
	Gpio_writePort(&LCD_DATA_PORT,data); // =GPIO_writeData(data); 
	//GPIO_writeData(data);     //PORTC = data;
}


 //Datasheet write mode timing diagram coding

void LCD_writeCmdData(uint8_t data) //LCD 내부 명령어 동작 //MCU-> LCD 로 명령어 보낼떄 (write mode)
{
	
	LCD_cmdMode();		    //명령어를 보내는 모드				RS bit 0
	LCD_writeMode();		//  r/w를 low로 보내야지 write mode  RW bit 0
	LCD_enableHigh();		//E 를 high로						E bit 1
	LCD_writeByte(data);       //8개 비트 전달하고				PORTC data  write
	LCD_enableLow();        //E 를 로우로						E bit 0
	//   이모든건 GPIO를 통해 OuTPUT하는것
	
}

void LCD_writeCharData(uint8_t data) // LCD char 쓰는 동작 //MCU-> LCD 로 Data 보낼떄 (write mode)
{
	LCD_charMode();		//RS bit 1
	LCD_writeMode();	//RW bit 0
	LCD_enableHigh();	// E bit 1
	LCD_writeByte(data);//PORTC data write 
	LCD_enableLow();	// e bit 0
}

void LCD_writeString(char *str) 
{
	for(int i=0; str[i];i++) //i가 0 부터 str가 널만날때까지
	{
		LCD_writeCharData(str[i]);
	}
}
void LCD_init()//LCD에 대한 init 함수
{
	Gpio_init();
	//DDRB = 3
	//DDRC = 8
	//p.12 reset function
	_delay_ms(15);
	
	
	LCD_writeCmdData(LCD_FUCTION_SET); // =LCD_writeCmdData(0x38);	  
	
	//function set (rs0 rw0(writemode) e0) 0 0 1 DL(1) N(1) F(0) -- (dontcare 0) = 0x38 명령어다 data 아님
	//LCD_writeCmdData(0x38);	        //instruct mode 로 mcu가 보냈기 때문에 LCD는  function set 이라 여기고
	//LCD_FUNCTION_SET 0x38
	
	_delay_ms(5);					//4.5ms 기다리라했으니깐
	LCD_writeCmdData(0x38);
	_delay_ms(1);				    //마이크로 섹 기다리라했으니까
	LCD_writeCmdData(0x38);
	LCD_writeCmdData(0x38);			// fs 한번더보내고
	//LCD_DISPLAY_OFF 0x08;
	LCD_writeCmdData(0x08);
	LCD_writeCmdData(0x01);
	LCD_writeCmdData(0x06);			//LCD_ENTRYMODE_SET 0000 0 1 1 0
	//초기화 끝
	//위에 display off 가있었으니깐 on 하나 넣어주자
	LCD_writeCmdData(0x0C);		    //LCD_DISPA
}


void LCD_gotoXY(uint8_t row, uint8_t col)
{
	col %= 16, row %=2 ;
	uint8_t lcdregisterAddress = (0x40 * row) + col;
	uint8_t command = 0x80 + lcdregisterAddress;
	LCD_writeCmdData(command);
}

void LCD_writeStringXY(uint8_t row, uint8_t col, char *str)
{
	LCD_gotoXY(row,col);
	LCD_writeString(str);
	
}
void LCD_displayClear() //디스플레이 클리어하는기능함수 만들어봄
{
	LCD_writeCmdData(LCD_DISPLAY_CLEAR);
}

