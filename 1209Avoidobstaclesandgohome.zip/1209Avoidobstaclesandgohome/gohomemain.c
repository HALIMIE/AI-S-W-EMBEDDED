#if 0
#include "device_driver.h"

#define LCDW			(320)
#define LCDH			(240)
#define X_MIN	 		(0)
#define X_MAX	 		(LCDW - 1)
#define Y_MIN	 		(0)
#define Y_MAX	 		(LCDH - 1)

#define TIMER_PERIOD	(10)  //timetick

static unsigned short color[] = {RED, YELLOW, GREEN, BLUE, WHITE, BLACK};  //color 

extern volatile int TIM4_expired;    //interrupt 
extern volatile int Jog_key_in;
extern volatile int Jog_key;

void Main(void)
{
	Uart_Printf("Game Project\n");    //teraterm printf

	Lcd_Init();
	Jog_Poll_Init();
	Jog_ISR_Enable(1);
	Uart1_RX_Interrupt_Enable(1);
	Lcd_Clr_Screen();

	int frog_pos_x = (LCDW / 2) - 10, frog_pos_y = Y_MAX - 20; //initial position
	int car_pos_x = 0, car_pos_y = 10;
	int car_pos_x1 = 40, car_pos_y1 = 40;
	int car_pos_x2 = 240, car_pos_y2 = 80 ;  //green
	int car_pos_x3 = 160, car_pos_y3 = 160; //(LCDH / 2) - 5;
	int car_pos_x4 = 80, car_pos_y4 = 200;  //white
	int frog_size = 20;

	int car_color = 1;              
	int tick_count = 0;

	TIM4_Repeat_Interrupt_Enable(1, TIMER_PERIOD*10);        //timer얼마마다 interrupt 걸지  10*10 =100ms 마다  
	Lcd_Draw_Box(frog_pos_x, frog_pos_y, 20, 20, color[0]);  //x,y 10pixel
	Lcd_Draw_Box(car_pos_x, car_pos_y, 20, 20, color[0]);  //크기크기
	Lcd_Draw_Box(car_pos_x1, car_pos_y1, 20, 20, color[1]);  //car 20 pixel  draw box   배경초록색 0 0 320 340
	Lcd_Draw_Box(car_pos_x2, car_pos_y2, 20, 20, color[2]);
	Lcd_Draw_Box(car_pos_x3, car_pos_y3, 20, 20, color[3]);
    Lcd_Draw_Box(car_pos_x4, car_pos_y4, 20, 20, color[4]);
	for(;;)
	{
		if(Jog_key_in)          		  //bell ring keyswith 눌림  키에의해 조작
		{
			Uart_Printf("KEY = %d\n", Jog_key);  //방향키와 푸쉬버튼 
			Lcd_Draw_Box(frog_pos_x, frog_pos_y, 20, 20, color[Jog_key]);
			if (Jog_key == 0) {  // Example: assuming 0 is for UP
                if (frog_pos_y > Y_MIN) frog_pos_y -= 5; // move up
            }
            else if (Jog_key == 3) {  // Assuming 1 is for RIGHT
                if (frog_pos_x < X_MAX - frog_size) frog_pos_x += 5; // move right
            }
            else if (Jog_key == 1) {  // Assuming 2 is for DOWN
                if (frog_pos_y < Y_MAX - frog_size) frog_pos_y += 5; // move down
            }
            else if (Jog_key == 2) {  // Assuming 3 is for LEFT
                if (frog_pos_x > X_MIN) frog_pos_x -= 5; // move left
            }

			Jog_key_in = 0;          	  //클리어시키는 작업
		}

		if(TIM4_expired)   					//timer에 의해 조작
		{
			tick_count = (tick_count + 1) % 10;    //tickcount 0-9까지 순회하는 코드 

			if(tick_count == 0)       //0이될때마다  so 1초마다 생삭바뀜 
			{
				Lcd_Draw_Box(car_pos_x, car_pos_y, 20, 20, color[car_color]);
				//car_color = (car_color + 1) % (sizeof(color)/sizeof(color[0]));
			}
			
			TIM4_expired = 0;   //클리어
		}
	}
}
#endif



#if 0
#include "device_driver.h"

#define LCDW            (320)
#define LCDH            (240)
#define X_MIN           (0)
#define X_MAX           (LCDW - 1)
#define Y_MIN           (0)
#define Y_MAX           (LCDH - 1)

#define TIMER_PERIOD    (10)  // timetick
#define SNAKE_SIZE      (20)  // snake segment size

static unsigned short color[] = {RED, YELLOW, GREEN, BLUE, WHITE, BLACK};  // color

extern volatile int TIM4_expired;    // interrupt 
extern volatile int Jog_key_in;
extern volatile int Jog_key;

typedef struct {
    int x, y;
} Position;

Position snake[100]; // 최대 100개의 뱀 몸통을 저장
int snake_length = 3;  // 초기 뱀 길이
int direction = 1;  // 0: Up, 1: Right, 2: Down, 3: Left
int food_x, food_y;  // 먹이 위치
int score = 0;  // 점수

void Lcd_Clear_Snake(Position *snake, int length) {
    for (int i = 0; i < length; i++) {
        Lcd_Draw_Box(snake[i].x, snake[i].y, SNAKE_SIZE, SNAKE_SIZE, color[5]);  // 지우기
    }
}

void Lcd_Draw_Snake(Position *snake, int length) {
    for (int i = 0; i < length; i++) {
        Lcd_Draw_Box(snake[i].x, snake[i].y, SNAKE_SIZE, SNAKE_SIZE, color[0]);  // 뱀 그리기
    }
}

void Generate_Food() {
    food_x = (rand() % (X_MAX / SNAKE_SIZE)) * SNAKE_SIZE;
    food_y = (rand() % (Y_MAX / SNAKE_SIZE)) * SNAKE_SIZE;
    Lcd_Draw_Box(food_x, food_y, SNAKE_SIZE, SNAKE_SIZE, color[1]);  // 먹이 그리기
}

int Check_Collision(Position *snake, int length) {
    // 벽에 부딪힌 경우
    if (snake[0].x < X_MIN || snake[0].x >= X_MAX || snake[0].y < Y_MIN || snake[0].y >= Y_MAX) {
        return 1;
    }
    // 자기 몸에 부딪힌 경우
    for (int i = 1; i < length; i++) {
        if (snake[0].x == snake[i].x && snake[0].y == snake[i].y) {
            return 1;
        }
    }
    return 0;
}

void Main(void)
{
    Uart_Printf("Snake Game\n");    // teraterm printf

    Lcd_Init();
    Jog_Poll_Init();
    Jog_ISR_Enable(1);
    Uart1_RX_Interrupt_Enable(1);
    Lcd_Clr_Screen();

    // 초기 뱀 위치 설정
    snake[0].x = (LCDW / 2) - SNAKE_SIZE;
    snake[0].y = (LCDH / 2) - SNAKE_SIZE;
    snake[1].x = snake[0].x - SNAKE_SIZE;
    snake[1].y = snake[0].y;
    snake[2].x = snake[0].x - (2 * SNAKE_SIZE);
    snake[2].y = snake[0].y;

    // 초기 먹이 생성
    Generate_Food();

    int tick_count = 0;

    TIM4_Repeat_Interrupt_Enable(1, TIMER_PERIOD * 10);        // timer interrupt every 100ms
    Lcd_Draw_Snake(snake, snake_length);  // 초기 뱀 그리기

    for (;;)
    {
        if (Jog_key_in)           // If key is pressed on the joystick
        {
            Uart_Printf("KEY = %d\n", Jog_key);  // print the key pressed

            // 방향 변경
            if (Jog_key == 0 && direction != 2) { direction = 0; }  // Up
            else if (Jog_key == 1 && direction != 3) { direction = 1; }  // Right
            else if (Jog_key == 2 && direction != 0) { direction = 2; }  // Down
            else if (Jog_key == 3 && direction != 1) { direction = 3; }  // Left

            Jog_key_in = 0;  // clear key input flag
        }

        if (TIM4_expired)    // Timer interrupt
        {
            Lcd_Clear_Snake(snake, snake_length);  // 기존 뱀 지우기

            // 뱀의 머리 위치 업데이트
            Position new_head = snake[0];
            if (direction == 0) { new_head.y -= SNAKE_SIZE; }  // 위로 이동
            else if (direction == 1) { new_head.x += SNAKE_SIZE; }  // 오른쪽으로 이동
            else if (direction == 2) { new_head.y += SNAKE_SIZE; }  // 아래로 이동
            else if (direction == 3) { new_head.x -= SNAKE_SIZE; }  // 왼쪽으로 이동

            // 뱀의 머리를 맨 앞에 추가
            for (int i = snake_length; i > 0; i--) {
                snake[i] = snake[i - 1];
            }
            snake[0] = new_head;

            // 먹이를 먹었는지 확인
            if (snake[0].x == food_x && snake[0].y == food_y) {
                score++;  // 점수 증가
                snake_length++;  // 뱀 길이 증가
                Generate_Food();  // 새로운 먹이 생성
            }

            // 충돌 체크
            if (Check_Collision(snake, snake_length)) {
                Uart_Printf("Game Over! Score: %d\n", score);
                Lcd_Clr_Screen();
                break;  // 게임 종료
            }

            Lcd_Draw_Snake(snake, snake_length);  // 뱀 다시 그리기

            TIM4_expired = 0;   // clear the timer flag
        }
    }
}
#endif

#if 0
#include "device_driver.h"
#include <stdlib.h>

#define LCDW (320)
#define LCDH (240)
#define X_MIN (0)
#define X_MAX (LCDW - 1)
#define Y_MIN (0)
#define Y_MAX (LCDH - 1)

#define TIMER_PERIOD (10)

static unsigned short color[] = {RED, YELLOW, GREEN, BLUE, WHITE, BLACK};

extern volatile int TIM4_expired;
extern volatile int Jog_key_in;
extern volatile int Jog_key;

void Main(void)
{
   Uart_Printf("Game Project\n");

   Lcd_Init();
   Jog_Poll_Init();
   Jog_ISR_Enable(1);
   Uart1_RX_Interrupt_Enable(1);
   Lcd_Clr_Screen();

   int car_pos_x_arr[] = {0, 40, 80, 120, 160, 200, 240, 280};
   int car_pos_y_arr[] = {0, 40, 80, 120, 160, 200};

   int score = 0;

   int frog_pos_x = (LCDW / 2) - 10, frog_pos_y = Y_MAX - 20;
   frog_pos_x = (frog_pos_x / 20) * 20;
   frog_pos_y = (frog_pos_y / 20) * 20;

   int car_pos_x = car_pos_x_arr[rand() % (sizeof(car_pos_x_arr) / sizeof(car_pos_x_arr[0]))];
   int car_pos_y = car_pos_y_arr[rand() % (sizeof(car_pos_y_arr) / sizeof(car_pos_y_arr[0]))];
   int car_color = 0;

   int trap_pos_x, trap_pos_y;
   do
   {
      trap_pos_x = car_pos_x_arr[rand() % (sizeof(car_pos_x_arr) / sizeof(car_pos_x_arr[0]))];
      trap_pos_y = car_pos_y_arr[rand() % (sizeof(car_pos_y_arr) / sizeof(car_pos_y_arr[0]))];
   } while ((trap_pos_x == frog_pos_x && trap_pos_y == frog_pos_y) || (trap_pos_x == car_pos_x && trap_pos_y == car_pos_y));

   int trap_color = 1;
   int tick_count = 0;
   int frog_color = 0;

   TIM4_Repeat_Interrupt_Enable(1, TIMER_PERIOD * 10);
   Lcd_Draw_Box(frog_pos_x, frog_pos_y, 20, 20, color[0]);
   Lcd_Draw_Box(car_pos_x, car_pos_y, 20, 20, color[0]);
   Lcd_Draw_Box(trap_pos_x, trap_pos_y, 20, 20, color[1]);

   for (;;)
   {
      if (frog_pos_x < car_pos_x + 20 && frog_pos_x + 20 > car_pos_x && frog_pos_y < car_pos_y + 20 && frog_pos_y + 20 > car_pos_y)
      {
         Uart_Printf("Score!\n");
         Lcd_Draw_Box(car_pos_x, car_pos_y, 20, 20, color[5]);
         score++;

         car_pos_x = car_pos_x_arr[rand() % (sizeof(car_pos_x_arr) / sizeof(car_pos_x_arr[0]))];
         car_pos_y = car_pos_y_arr[rand() % (sizeof(car_pos_y_arr) / sizeof(car_pos_y_arr[0]))];
         car_color = (car_color + 1) % (sizeof(color) / sizeof(color[0]) - 1);

         Lcd_Draw_Box(car_pos_x, car_pos_y, 20, 20, color[car_color]);

         frog_color = (frog_color + 1) % (sizeof(color) / sizeof(color[0]) - 1);
         Lcd_Draw_Box(frog_pos_x, frog_pos_y, 20, 20, color[frog_color]);

         Lcd_Draw_Box(trap_pos_x, trap_pos_y, 20, 20, color[5]);

         do
         {
            trap_pos_x = car_pos_x_arr[rand() % (sizeof(car_pos_x_arr) / sizeof(car_pos_x_arr[0]))];
            trap_pos_y = car_pos_y_arr[rand() % (sizeof(car_pos_y_arr) / sizeof(car_pos_y_arr[0]))];
         } while ((trap_pos_x == frog_pos_x && trap_pos_y == frog_pos_y) || (trap_pos_x == car_pos_x && trap_pos_y == car_pos_y));

         do
         {
            trap_color = rand() % (sizeof(color) / sizeof(color[0]) - 1);
         } while (trap_color == frog_color || trap_color == car_color);

         Lcd_Draw_Box(trap_pos_x, trap_pos_y, 20, 20, color[trap_color]);
      }
      else if (frog_pos_x < trap_pos_x + 20 && frog_pos_x + 20 > trap_pos_x && frog_pos_y < trap_pos_y + 20 && frog_pos_y + 20 > trap_pos_y)
      {
         Uart_Printf("Game Over!\n");
         Uart_Printf("Score: %d\n", score);
         break;
      }

      if (Jog_key_in)
      {
         Uart_Printf("KEY = %d\n", Jog_key);
         Lcd_Draw_Box(frog_pos_x, frog_pos_y, 20, 20, color[5]);

         switch (Jog_key)
         {
         case 0:
            if (frog_pos_y > Y_MIN)
               frog_pos_y -= 20;
            break;
         case 1:
            if (frog_pos_y < Y_MAX - 20)
               frog_pos_y += 20;
            break;
         case 2:
            if (frog_pos_x > X_MIN)
               frog_pos_x -= 20;
            break;
         case 3:
            if (frog_pos_x < X_MAX - 20)
               frog_pos_x += 20;
            break;
         }
         Lcd_Draw_Box(frog_pos_x, frog_pos_y, 20, 20, color[frog_color]);
         Jog_key_in = 0;
      }

      if (TIM4_expired)
      {
         tick_count = (tick_count + 1) % 10;
         
         TIM4_expired = 0;
      }
   }
}
#endif

#if 0
#include "device_driver.h"
#include <stdlib.h>

#define LCDW (320)
#define LCDH (240)
#define X_MIN (0)
#define X_MAX (LCDW - 1)
#define Y_MIN (0)
#define Y_MAX (LCDH - 1)

#define TIMER_PERIOD (10)

static unsigned short color[] = {RED, YELLOW, GREEN, BLUE, WHITE, BLACK};
static unsigned short Carcolor[] = {RED, YELLOW, GREEN, BLUE, WHITE};

extern volatile int TIM4_expired;
extern volatile int Jog_key_in;
extern volatile int Jog_key;

void Main(void)
{
   Uart_Printf("Game Project\n");

   Lcd_Init();
   Jog_Poll_Init();
   Jog_ISR_Enable(1);
   Uart1_RX_Interrupt_Enable(1);
   Lcd_Clr_Screen();

   int car_pos_x_arr[] = {0, 40, 80, 120, 160, 200, 240, 280};
   int car_pos_y_arr[] = {0, 40, 80, 120, 160, 200};

   int score = 0;

   int frog_pos_x = (LCDW / 2) - 10, frog_pos_y = Y_MAX - 20;
   frog_pos_x = (frog_pos_x / 20) * 20;
   frog_pos_y = (frog_pos_y / 20) * 20;

   int car_pos_x = car_pos_x_arr[rand() % (sizeof(car_pos_x_arr) / sizeof(car_pos_x_arr[0]))];
   int car_pos_y = car_pos_y_arr[rand() % (sizeof(car_pos_y_arr) / sizeof(car_pos_y_arr[0]))];
   int car_color = 0;

   int trap_pos_x, trap_pos_y;
 
   do
   {
      trap_pos_x = car_pos_x_arr[rand() % (sizeof(car_pos_x_arr) / sizeof(car_pos_x_arr[0]))];
      trap_pos_y = car_pos_y_arr[rand() % (sizeof(car_pos_y_arr) / sizeof(car_pos_y_arr[0]))];
   } while ((trap_pos_x == frog_pos_x && trap_pos_y == frog_pos_y) || (trap_pos_x == car_pos_x && trap_pos_y == car_pos_y));

   int trap_color = 1;
   int tick_count = 0;
   int frog_color = 0;

   TIM4_Repeat_Interrupt_Enable(1, TIMER_PERIOD * 10);
   Lcd_Draw_Box(frog_pos_x, frog_pos_y, 20, 20, color[0]);
   Lcd_Draw_Box(car_pos_x, car_pos_y, 20, 20, Carcolor[0]);
   Lcd_Draw_Box(trap_pos_x, trap_pos_y, 20, 20, color[1]);

   for (;;)
   {
      if (frog_pos_x < car_pos_x + 20 && frog_pos_x + 20 > car_pos_x && frog_pos_y < car_pos_y + 20 && frog_pos_y + 20 > car_pos_y)
      {
         Uart_Printf("Score!\n");
         Lcd_Draw_Box(car_pos_x, car_pos_y, 20, 20, Carcolor[5]);
         score++;
         car_pos_x = car_pos_x_arr[rand() % (sizeof(car_pos_x_arr) / sizeof(car_pos_x_arr[0]))];
         car_pos_y = car_pos_y_arr[rand() % (sizeof(car_pos_y_arr) / sizeof(car_pos_y_arr[0]))];
         car_color = (car_color + 1) % (sizeof(color) / sizeof(Carcolor[0]) - 1);
         frog_color = (frog_color + 1) % (sizeof(color) / sizeof(color[0]) - 1);

         Lcd_Draw_Box(car_pos_x, car_pos_y, 20, 20, Carcolor[car_color]);
         Lcd_Draw_Box(frog_pos_x, frog_pos_y, 20, 20, color[frog_color]);
         Lcd_Draw_Box(trap_pos_x, trap_pos_y, 20, 20, color[5]);

         do
         {
            trap_pos_x = car_pos_x_arr[rand() % (sizeof(car_pos_x_arr) / sizeof(car_pos_x_arr[0]))];
            trap_pos_y = car_pos_y_arr[rand() % (sizeof(car_pos_y_arr) / sizeof(car_pos_y_arr[0]))];
         } while ((trap_pos_x == frog_pos_x && trap_pos_y == frog_pos_y) || (trap_pos_x == car_pos_x && trap_pos_y == car_pos_y));

         do
         {
            trap_color = rand() % (sizeof(color) / sizeof(color[0]) - 1);
         } while (trap_color == frog_color || trap_color == car_color);

         Lcd_Draw_Box(trap_pos_x, trap_pos_y, 20, 20, color[trap_color]);
      }
      else if (frog_pos_x < trap_pos_x + 20 && frog_pos_x + 20 > trap_pos_x && frog_pos_y < trap_pos_y + 20 && frog_pos_y + 20 > trap_pos_y)
      {
         Uart_Printf("Game Over!\n");
         Uart_Printf("Score: %d\n", score);
         break;
      }

      if (Jog_key_in)
      {
         Uart_Printf("KEY = %d\n", Jog_key);
         Lcd_Draw_Box(frog_pos_x, frog_pos_y, 20, 20, color[5]);

         switch (Jog_key)
         {
         case 0:
            if (frog_pos_y > Y_MIN)
               frog_pos_y -= 20;
            break;
         case 1:
            if (frog_pos_y < Y_MAX - 20)
               frog_pos_y += 20;
            break;
         case 2:
            if (frog_pos_x > X_MIN)
               frog_pos_x -= 20;
            break;
         case 3:
            if (frog_pos_x < X_MAX - 20)
               frog_pos_x += 20;
            break;
         }
         Lcd_Draw_Box(frog_pos_x, frog_pos_y, 20, 20, color[frog_color]);
         Jog_key_in = 0;
      }

      if (TIM4_expired)
      {
         tick_count = (tick_count + 1) % 50;
         if (tick_count == 0)
         {
            // update trap position
            Lcd_Draw_Box(trap_pos_x, trap_pos_y, 20, 20, color[5]);
            do
            {
               trap_pos_x = car_pos_x_arr[rand() % (sizeof(car_pos_x_arr) / sizeof(car_pos_x_arr[0]))];
               trap_pos_y = car_pos_y_arr[rand() % (sizeof(car_pos_y_arr) / sizeof(car_pos_y_arr[0]))];
            } while ((trap_pos_x == frog_pos_x && trap_pos_y == frog_pos_y) || (trap_pos_x == car_pos_x && trap_pos_y == car_pos_y));
            Lcd_Draw_Box(trap_pos_x, trap_pos_y, 20, 20, color[trap_color]);
         }
         TIM4_expired = 0;
      }
   }
}
#endif


#if 0
#include "device_driver.h"
#include <stdlib.h>

#define LCDW (320)
#define LCDH (240)
#define X_MIN (0)
#define X_MAX (LCDW - 1)
#define Y_MIN (0)
#define Y_MAX (LCDH - 1)

#define TIMER_PERIOD (10)

static unsigned short color[] = {YELLOW, GREEN, BLUE, WHITE};
static unsigned short Redcolor[] = {RED};

extern volatile int TIM4_expired;
extern volatile int Jog_key_in;
extern volatile int Jog_key;

void Main(void)
{
   Uart_Printf("Game Project\n");

   Lcd_Init();
   Jog_Poll_Init();
   Jog_ISR_Enable(1);
   Uart1_RX_Interrupt_Enable(1);
   Lcd_Clr_Screen();

   int car_pos_x_arr[] = {0, 40, 80, 120, 160, 200, 240, 280, 300};
   int car_pos_y_arr[] = {0, 40, 80, 120, 160, 200,220};

   int score = 0;

   int frog_pos_x = (LCDW / 2) - 10, frog_pos_y = Y_MAX - 20;
   frog_pos_x = (frog_pos_x / 20) * 20;
   frog_pos_y = (frog_pos_y / 20) * 20;

   int car_pos_x = car_pos_x_arr[rand() % (sizeof(car_pos_x_arr) / sizeof(car_pos_x_arr[0]))];
   int car_pos_y = car_pos_y_arr[rand() % (sizeof(car_pos_y_arr) / sizeof(car_pos_y_arr[0]))];
   int car_color = 0;

   // 트랩 위치 배열
   int trap_pos_x_arr[4], trap_pos_y_arr[4];
   int trap_color[4];  // 4개의 트랩 색상

   // 초기 트랩 위치 및 색상 설정
   int i;  // for 루프 변수
   for (i = 0; i < 4; i++)
   {
      do
      {
         trap_pos_x_arr[i] = car_pos_x_arr[rand() % (sizeof(car_pos_x_arr) / sizeof(car_pos_x_arr[0]))];
         trap_pos_y_arr[i] = car_pos_y_arr[rand() % (sizeof(car_pos_y_arr) / sizeof(car_pos_y_arr[0]))];
      } while ((trap_pos_x_arr[i] == frog_pos_x && trap_pos_y_arr[i] == frog_pos_y) || (trap_pos_x_arr[i] == car_pos_x && trap_pos_y_arr[i] == car_pos_y));
      
      // 랜덤 색상 설정 (개구리 색상과 자동차 색상과 겹치지 않도록)
      do
      {
         trap_color[i] = rand() % (sizeof(color) / sizeof(color[0]) - 1);
      } while (trap_color[i] == car_color);  // 트랩이 자동차 색상과 겹치지 않게 설정
   }

   // 개구리 색상 변수 선언 및 초기화
   int frog_color = Redcolor[0];  // 처음에는 첫 번째 색상 (RED)

   int tick_count = 0;

   TIM4_Repeat_Interrupt_Enable(1, TIMER_PERIOD * 2);  //속도빠르게
   Lcd_Draw_Box(frog_pos_x, frog_pos_y, 20, 20, Redcolor[0]);  // 개구리 색상 초기화
   Lcd_Draw_Box(car_pos_x, car_pos_y, 20, 20, Redcolor[0]);  // 자동차 색상 초기화

   // 초기 트랩 그리기
   for (i = 0; i < 4; i++)
   {
      Lcd_Draw_Box(trap_pos_x_arr[i], trap_pos_y_arr[i], 20, 20, color[trap_color[i]]);
   }

   for (;;)
   {
      // 개구리와 트랩이 겹치면 게임 종료
      for (i = 0; i < 4; i++)
      {
         if (frog_pos_x < trap_pos_x_arr[i] + 20 && frog_pos_x + 20 > trap_pos_x_arr[i] && frog_pos_y < trap_pos_y_arr[i] + 20 && frog_pos_y + 20 > trap_pos_y_arr[i])
         {
            Uart_Printf("Game Over!\n");
            Uart_Printf("Score: %d\n", score);
            return;  // 게임 종료
         }
      }

      // 개구리와 자동차가 겹치면 점수 증가
      if (frog_pos_x < car_pos_x + 20 && frog_pos_x + 20 > car_pos_x && frog_pos_y < car_pos_y + 20 && frog_pos_y + 20 > car_pos_y)
      {
         Uart_Printf("Score!\n");
         Lcd_Draw_Box(car_pos_x, car_pos_y, 20, 20, Redcolor[0]);
         score++;
         car_pos_x = car_pos_x_arr[rand() % (sizeof(car_pos_x_arr) / sizeof(car_pos_x_arr[0]))];
         car_pos_y = car_pos_y_arr[rand() % (sizeof(car_pos_y_arr) / sizeof(car_pos_y_arr[0]))];
         car_color = Redcolor[0];
         frog_color = Redcolor[0];

         Lcd_Draw_Box(car_pos_x, car_pos_y, 20, 20, Redcolor[0]);
         Lcd_Draw_Box(frog_pos_x, frog_pos_y, 20, 20, Redcolor[0]);

         // 트랩 위치 업데이트
         for (i = 0; i < 4; i++)
         {
            do
            {
               trap_pos_x_arr[i] = car_pos_x_arr[rand() % (sizeof(car_pos_x_arr) / sizeof(car_pos_x_arr[0]))];
               trap_pos_y_arr[i] = car_pos_y_arr[rand() % (sizeof(car_pos_y_arr) / sizeof(car_pos_y_arr[0]))];
            } while ((trap_pos_x_arr[i] == frog_pos_x && trap_pos_y_arr[i] == frog_pos_y) || (trap_pos_x_arr[i] == car_pos_x && trap_pos_y_arr[i] == car_pos_y));
            
            do
            {
               trap_color[i] = rand() % (sizeof(color) / sizeof(color[0]) - 1);
            } while (trap_color[i] == car_color || trap_color[i] == frog_color);
         }
      }

      // 키 입력 처리
      if (Jog_key_in)
      {
         Uart_Printf("KEY = %d\n", Jog_key);
         Lcd_Draw_Box(frog_pos_x, frog_pos_y, 20, 20, color[5]);

         switch (Jog_key)
         {
         case 0:
            if (frog_pos_y > Y_MIN)
               frog_pos_y -= 20;
            break;
         case 1:
            if (frog_pos_y < Y_MAX - 20)
               frog_pos_y += 20;
            break;
         case 2:
            if (frog_pos_x > X_MIN)
               frog_pos_x -= 20;
            break;
         case 3:
            if (frog_pos_x < X_MAX - 20)
               frog_pos_x += 20;
            break;
         }
         Lcd_Draw_Box(frog_pos_x, frog_pos_y, 20, 20, Redcolor[0]);
         Jog_key_in = 0;
      }

      // 타이머 만료 처리
      if (TIM4_expired)
      {
         tick_count = (tick_count + 1) % 5;
         if (tick_count == 0)
         {
            // 기존 트랩을 지우고 새로운 위치에 그리기
            for (i = 0; i < 4; i++)
            {
               Lcd_Draw_Box(trap_pos_x_arr[i], trap_pos_y_arr[i], 20, 20, color[4]);
               do
               {
                  trap_pos_x_arr[i] = car_pos_x_arr[rand() % (sizeof(car_pos_x_arr) / sizeof(car_pos_x_arr[0]))];
                  trap_pos_y_arr[i] = car_pos_y_arr[rand() % (sizeof(car_pos_y_arr) / sizeof(car_pos_y_arr[0]))];
               } while ((trap_pos_x_arr[i] == frog_pos_x && trap_pos_y_arr[i] == frog_pos_y) || (trap_pos_x_arr[i] == car_pos_x && trap_pos_y_arr[i] == car_pos_y));

               Lcd_Draw_Box(trap_pos_x_arr[i], trap_pos_y_arr[i], 20, 20, color[trap_color[i]]);
            }
         }
         TIM4_expired = 0;
      }
   }
}
#endif

#include "device_driver.h"
#include <stdlib.h>

#define LCDW (320)
#define LCDH (240)
#define X_MIN (0)
#define X_MAX (LCDW - 1)
#define Y_MIN (0)
#define Y_MAX (LCDH - 1)

#define TIMER_PERIOD (10)

static unsigned short color[] = {RED, YELLOW, GREEN, BLUE, WHITE};  // BLACK을 제거한 색 배열
static unsigned short Carcolor[] = {RED, YELLOW, GREEN, BLUE, WHITE};

extern volatile int TIM4_expired;
extern volatile int Jog_key_in;
extern volatile int Jog_key;

void Main(void)
{
   Uart_Printf("Game Project\n");

   Lcd_Init();
   Jog_Poll_Init();
   Jog_ISR_Enable(1);
   Uart1_RX_Interrupt_Enable(1);
   Lcd_Clr_Screen();

   int car_pos_x_arr[] = {0, 40, 80, 120, 160, 200, 240, 280, 300};
   int car_pos_y_arr[] = {0, 40, 80, 120, 160, 200};

   int score = 0;

   int frog_pos_x = (LCDW / 2) - 10, frog_pos_y = Y_MAX - 20;
   frog_pos_x = (frog_pos_x / 20) * 20;
   frog_pos_y = (frog_pos_y / 20) * 20;

   int car_pos_x = car_pos_x_arr[rand() % (sizeof(car_pos_x_arr) / sizeof(car_pos_x_arr[0]))];
   int car_pos_y = car_pos_y_arr[rand() % (sizeof(car_pos_y_arr) / sizeof(car_pos_y_arr[0]))];
   int car_color = 0;

   // 트랩 위치 배열
   int trap_pos_x_arr[4], trap_pos_y_arr[4];
   int trap_color[4];  // 4개의 트랩 색상

   // 초기 트랩 위치 및 색상 설정
   int i;  // for 루프 변수
   for (i = 0; i < 4; i++)
   {
      do
      {
         trap_pos_x_arr[i] = car_pos_x_arr[rand() % (sizeof(car_pos_x_arr) / sizeof(car_pos_x_arr[0]))];
         trap_pos_y_arr[i] = car_pos_y_arr[rand() % (sizeof(car_pos_y_arr) / sizeof(car_pos_y_arr[0]))];
      } while ((trap_pos_x_arr[i] == frog_pos_x && trap_pos_y_arr[i] == frog_pos_y) || (trap_pos_x_arr[i] == car_pos_x && trap_pos_y_arr[i] == car_pos_y));
      
      // 랜덤 색상 설정 (개구리 색상과 자동차 색상과 겹치지 않도록)
      do
      {
         trap_color[i] = rand() % (sizeof(color) / sizeof(color[0]));  // BLACK을 제외한 색만 선택
      } while (trap_color[i] == car_color);  // 트랩이 자동차 색상과 겹치지 않게 설정
   }

   // 개구리 색상 변수 선언 및 초기화
   int frog_color = 0;  // 처음에는 첫 번째 색상 (RED)

   int tick_count = 0;

   TIM4_Repeat_Interrupt_Enable(1, TIMER_PERIOD * 3);
   Lcd_Draw_Box(frog_pos_x, frog_pos_y, 20, 20, color[0]);  // 개구리 색상 초기화
   Lcd_Draw_Box(car_pos_x, car_pos_y, 20, 20, Carcolor[0]);  // 자동차 색상 초기화

   // 초기 트랩 그리기
   for (i = 0; i < 4; i++)
   {
      Lcd_Draw_Box(trap_pos_x_arr[i], trap_pos_y_arr[i], 20, 20, color[trap_color[i]]);
   }

   for (;;)
   {
      // 개구리와 트랩이 겹치면 게임 종료
      for (i = 0; i < 4; i++)
      {
         if (frog_pos_x < trap_pos_x_arr[i] + 20 && frog_pos_x + 20 > trap_pos_x_arr[i] && frog_pos_y < trap_pos_y_arr[i] + 20 && frog_pos_y + 20 > trap_pos_y_arr[i])
         {
            Uart_Printf("Game Over!\n");
            Uart_Printf("Score: %d\n", score);
            return;  // 게임 종료
         }
      }

      // 개구리와 자동차가 겹치면 점수 증가
      if (frog_pos_x < car_pos_x + 20 && frog_pos_x + 20 > car_pos_x && frog_pos_y < car_pos_y + 20 && frog_pos_y + 20 > car_pos_y)
      {
         Uart_Printf("Score!\n");

         // 이전에 그려진 자동차 지우기
         Lcd_Draw_Box(car_pos_x, car_pos_y, 20, 20, color[5]);  // 배경색으로 덮어쓰기

         // 점수 증가 후 새로운 위치로 자동차 그리기
         score++;
         car_pos_x = car_pos_x_arr[rand() % (sizeof(car_pos_x_arr) / sizeof(car_pos_x_arr[0]))];
         car_pos_y = car_pos_y_arr[rand() % (sizeof(car_pos_y_arr) / sizeof(car_pos_y_arr[0]))];
         car_color = (car_color + 1) % (sizeof(Carcolor) / sizeof(Carcolor[0]) - 1);
         frog_color = (frog_color + 1) % (sizeof(color) / sizeof(color[0]) - 1);

         Lcd_Draw_Box(car_pos_x, car_pos_y, 20, 20, Carcolor[car_color]);
         Lcd_Draw_Box(frog_pos_x, frog_pos_y, 20, 20, color[frog_color]);

         // 트랩 위치 업데이트
         for (i = 0; i < 4; i++)
         {
            // 기존 트랩을 지우고 새로운 트랩 위치로 업데이트
            Lcd_Draw_Box(trap_pos_x_arr[i], trap_pos_y_arr[i], 20, 20, color[5]);  // 기존 트랩을 배경색으로 덮어씌움
            do
            {
               trap_pos_x_arr[i] = car_pos_x_arr[rand() % (sizeof(car_pos_x_arr) / sizeof(car_pos_x_arr[0]))];
               trap_pos_y_arr[i] = car_pos_y_arr[rand() % (sizeof(car_pos_y_arr) / sizeof(car_pos_y_arr[0]))];
            } while ((trap_pos_x_arr[i] == frog_pos_x && trap_pos_y_arr[i] == frog_pos_y) || (trap_pos_x_arr[i] == car_pos_x && trap_pos_y_arr[i] == car_pos_y));
            
            do
            {
               trap_color[i] = rand() % (sizeof(color) / sizeof(color[0]));  // BLACK을 제외한 색만 선택
            } while (trap_color[i] == car_color || trap_color[i] == frog_color);

            // 새로운 트랩 그리기
            Lcd_Draw_Box(trap_pos_x_arr[i], trap_pos_y_arr[i], 20, 20, color[trap_color[i]]);
         }
      }

      // 키 입력 처리
      if (Jog_key_in)
      {
         Uart_Printf("KEY = %d\n", Jog_key);
         Lcd_Draw_Box(frog_pos_x, frog_pos_y, 20, 20, color[5]);

         switch (Jog_key)
         {
         case 0:
            if (frog_pos_y > Y_MIN)
               frog_pos_y -= 20;
            break;
         case 1:
            if (frog_pos_y < Y_MAX - 20)
               frog_pos_y += 20;
            break;
         case 2:
            if (frog_pos_x > X_MIN)
               frog_pos_x -= 20;
            break;
         case 3:
            if (frog_pos_x < X_MAX - 20)
               frog_pos_x += 20;
            break;
         }
         Lcd_Draw_Box(frog_pos_x, frog_pos_y, 20, 20, color[frog_color]);
         Jog_key_in = 0;
      }

      // 타이머 만료 처리
      if (TIM4_expired)
      {
         tick_count = (tick_count + 1) % 50;
         if (tick_count == 0)
         {
            // 기존 트랩을 지우고 새로운 위치에 그리기
            for (i = 0; i < 4; i++)
            {
               Lcd_Draw_Box(trap_pos_x_arr[i], trap_pos_y_arr[i], 20, 20, color[5]);  // 기존 트랩을 배경색으로 지움
               do
               {
                  trap_pos_x_arr[i] = car_pos_x_arr[rand() % (sizeof(car_pos_x_arr) / sizeof(car_pos_x_arr[0]))];
                  trap_pos_y_arr[i] = car_pos_y_arr[rand() % (sizeof(car_pos_y_arr) / sizeof(car_pos_y_arr[0]))];
               } while ((trap_pos_x_arr[i] == frog_pos_x && trap_pos_y_arr[i] == frog_pos_y) || (trap_pos_x_arr[i] == car_pos_x && trap_pos_y_arr[i] == car_pos_y));

               Lcd_Draw_Box(trap_pos_x_arr[i], trap_pos_y_arr[i], 20, 20, color[trap_color[i]]);
            }
         }
         TIM4_expired = 0;
      }
   }
}