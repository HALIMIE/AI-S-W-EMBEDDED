﻿/*
 * LED.h
 *
 * Created: 2024-11-26 오후 1:11:40
 *  Author: KCCISTC
 */ 

#include <avr/io.h>  //추가
#define F_CPU 16000000UL
#include <util/delay.h>

#define LED_DDR DDRD
#define LED_PORT PORTD
#ifndef LED_H_
#define LED_H_

void Led_init();

void Led_WriteData(uint8_t data);  //

void Led_allOff() ; 

void Led_allOn();


#endif /* LED_H_ */