﻿/*
 * TrafficSignal.h
 *
 * Created: 2024-11-26 오후 1:51:15
 *  Author: KCCISTC
 */ 


#ifndef TRAFFICSIGNAL_H_
#define TRAFFICSIGNAL_H_
#define F_CPU 16000000UL
#include <avr/io.h>
#include <util/delay.h>

#include "../../TSDriver/TSButton/Button.h"
#include "../../TSDriver/TSLED/LED.h"
#define B_AUTO			0
#define B_MANUAL		1
#define B_SWITCHING		2
enum{AUTO,MANUAL};
enum{RED_GREEN, RED_YELLOW,GREEN_RED,YELLOW_RED};

void TrafficSignal_Auto();
void TrafficSignal_Manual();
void TrafficSignal_RedGreen();
void TrafficSignal_RedYellow();
void TrafficSignal_GreenRed();
void TrafficSignal_YellowRed();
void TrafficSignal_init();
void TrafficSignal_execute();




#endif /* TRAFFICSIGNAL_H_ */