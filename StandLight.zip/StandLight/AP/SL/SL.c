﻿
#include "SL.h"

uint8_t LightState;			 //uint8_t trafficState;
uint32_t timeTick = 0;
uint8_t ledData;
button_t btnOff, btnNext;   //button_t btnAuto, btnManual, btnSwitching; 
uint8_t btnState;			 //uint8_t trafficModeState;

void SL_init()
{
	Led_init();
	ledData = 0x00;
	btnState = OFF;
	
	Button_init(&btnNext, &DDRA, &PINA,0);
	Button_init(&btnOff, &DDRA, &PINA,1);
	
	
	LightState = L0;
	
}

void SL_execute()
{
	if(Button_GetState(&btnNext) == ACT_RELEASED)  //버튼눌렸는지 체크 오토모드 인지 메뉴얼 모드인지
	{
		LightState ++;
		if(LightState == 5)
		LightState = 0;
		
	}
	else if(Button_GetState(&btnOff) == ACT_RELEASED)
	{
		LightState = L0;
	}
	
	//모드러닝 눌리든말든 스위치 실행
	
	switch(LightState)
	{
		
		
		case L0:
		Led_allOff();
		break;
		case L1:
		{
			Light_1();
		}
		break;
		case L2:
		{
		Light_1();
		Light_2();
		}
		break;
		case L3:
		Light_1();
		Light_3();
		break;
		case L4:
		Light_1();
		Light_4();
		break;
	}
	_delay_ms(1);
	timeTick++;
}

//void TrafficSignal_Auto()  //첨에 이함수 호출
//{
	//
	//static uint32_t prevTime = 0; // 딜레이 막아보자
	//switch (trafficState) // 트래픽 스테이트에 따라서 스위치문 또 실행
	//{
		//case RED_GREEN:
		//TrafficSignal_RedGreen();
		////_delay_ms(3000); //수동일떄는 지우고  if문
		////if((trafficButtonPIN & (1<<B_SWITCHING))==0)
		//
		////delay 지우고 프면 timetick은플플플플계속 올라가는거 prevtime은
		////
		//if(timeTick - prevTime >=3000)    //이 조건시 prevtime은 0이니깐 타임틱이 3000될떄까지는 계속이프문 안들어가다
		//{
			//prevTime = timeTick ;            //3000넘으면
			//trafficState = RED_YELLOW;
			//
		//}
		//
		//break;
		//
		//
		//case RED_YELLOW:
		//TrafficSignal_RedYellow();
		////_delay_ms(1000);
		//if(timeTick - prevTime >=1000)
		//{
			//prevTime = timeTick ;  //4000을 넣고 프리브타임에
			//trafficState = GREEN_RED;  //상태변환
			//
		//}
		//
		//break;
		//case GREEN_RED:
		//TrafficSignal_GreenRed();
		////_delay_ms(3000);
		//
		//if(timeTick - prevTime >=3000)
		//{
			//prevTime = timeTick ;  //4000을 넣고 프리브타임에
			//trafficState = YELLOW_RED;  //상태변환
			//
		//}
		//break;
		//case YELLOW_RED:
		//TrafficSignal_YellowRed();
		////_delay_ms(1000);
		//if(timeTick - prevTime >=1000)
		//{
			//prevTime = timeTick ;  //4000을 넣고 프리브타임에
			//trafficState = RED_GREEN;  //상태변환
			//
		//}
		//
		//break;
		//
	//}
//}
//void TrafficSignal_Manual()
//{
	//switch (trafficState)
	//{
		//case RED_GREEN:
		//TrafficSignal_RedGreen();
		////_delay_ms(3000);
		//if(Button_GetState(&btnSwitching) == ACT_RELEASED)
		//{
			//trafficState = RED_YELLOW;
			//
		//}
		//
		//
		//break;
		//case RED_YELLOW:
		//TrafficSignal_RedYellow();
		////_delay_ms(1000);
		//if(Button_GetState(&btnSwitching) == ACT_RELEASED)
		//{
			//trafficState = GREEN_RED;
		//}
		//break;
		//case GREEN_RED:
		//TrafficSignal_GreenRed();
		////_delay_ms(1000);
		//if(Button_GetState(&btnSwitching) == ACT_RELEASED)
		//{
			//trafficState = YELLOW_RED;
		//}
		//break;
		//case YELLOW_RED:
		//TrafficSignal_YellowRed();
		//
		////_delay_ms(1000);
		//if((Button_GetState(&btnSwitching)) == ACT_RELEASED)
		//{
			//trafficState = RED_GREEN;
		//}
		//break;
		//
	//}
	//
//}