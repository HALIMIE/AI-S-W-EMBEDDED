#define KEY_MSG 0x3330

struct msg_buf {
	long mtype;
	char mtext[64];
};

