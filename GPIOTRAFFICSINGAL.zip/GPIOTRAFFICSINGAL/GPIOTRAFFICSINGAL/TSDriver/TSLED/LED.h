﻿/*
 * LED.h
 *
 * Created: 2024-11-26 오후 1:11:40
 *  Author: KCCISTC
 */ 

#include <avr/io.h>  //추가
#define F_CPU 16000000UL
#include <util/delay.h>


#define trafficLedDDR DDRF
#define trafficLedPORT PORTF
	
#ifndef LED_H_
#define LED_H_

void Led_init();

void Led_WriteData(uint8_t data);  //

void Led_allOff() ; 

void Led_allOn();

void TrafficSignal_RedGreen();

void TrafficSignal_RedYellow();

void TrafficSignal_GreenRed();

void TrafficSignal_YellowRed();



#endif /* LED_H_ */