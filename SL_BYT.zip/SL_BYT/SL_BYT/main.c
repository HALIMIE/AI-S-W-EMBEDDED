

#include <avr/io.h>
#define F_CPU 16000000UL
#include <util/delay.h>
#include "ap/StandLight/StandLight.h"
#include "periph/GPIO/GPIO.h"



int main(void)
{
	
	StandLight_init();
	
	
	while (1)
	{
		
		StandLight_run();
	}
}








#if 0
int main(void)
{
	
    StandLight_init();
	//DDRD = 0xff; 대신에
	Gpio_initPort(&DDRD, OUTPUT);
	
    while (1) 
    {
		//PORTD = 0xff;
		Gpio_writePort(&PORTD,0xff);
		_delay_ms(200);
		//PORTD = 0x00;
		Gpio_writePort(&PORTD,0x00);
		_delay_ms(200);
		
		StandLight_execute();
    }
}
#endif
#if 0
int main() // DDRA 포트에 연결된 버튼 2개 초기화 
{				//버튼1누르면 all led on 2 all led off
	StandLight_init();
	Gpio_initPin(&PINA,1,INPUT);
	Gpio_initPin(&PINA,2,INPUT);
	Gpio_initPort(&DDRD, OUTPUT);
	
	while(1)
	{
		if(Gpio_readPin(&PINA, 0) == 0 )
		
		 Gpio_writePort(&PORTD,0xff);
		
		if( Gpio_readPin(&PINA, 1) == 0 )
		Gpio_writePort(&PORTD,0x00);
		
		
	}

}
#endif

