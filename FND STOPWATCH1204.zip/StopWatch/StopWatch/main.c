#define F_CPU 16000000UL
#include <avr/io.h>
#include <util/delay.h>
#include <avr/interrupt.h>
#include "Driver/FND/FND.h"
#include "Driver/BUTTON/button.h"
#include "periph/GPIO/GPIO.h"
#include "periph/TIM/TIM.h"
#include "common/TimeTick/TimeTick.h"
#include "ap/StopWatch/StopWatch.h"

#define D1 0b01110000  //첫째자리
#define D2 0b10110000  //둘째
#define D3 0b11010000
#define D4 0b11100000  //넷째자리
#define N0 0b00111111
#define N1 0b00000110
#define N2 0x5b
#define N3 ox4f
#define N4 0x66
#define N5 0x6d
#define N6 0x7d
#define N7 0x07
#define N8 0x7f
#define N9 0x67
#define DAS 0b01000000


//uint16_t milisec;

	//딜레이 없애는 작업
	//PORTE |= ((1<<7) | (1<<6) | (1<<5) | (1<<4) ); //불을 끈다 1이 들어오면 꺼지니 캐소드타입
	//
//
	//PORTF = fndFont[fndNum/1000%10];
	//PORTE &= ~(1<<4);
	////PORTF = fndFont[1];
	//_delay_ms(1);
	//
	//PORTE |= ( ( 1<<7) | (1<<6) | (1<<5) | (1<<4) );  //불을 끈다 1이 들어오면 꺼지니 캐소드타입
	//PORTF = fndFont[fndNum/100%10];
	//PORTE &= ~(1<<5);
	////PORTF = fndFont[2];
	//_delay_ms(1);
	//
	//PORTE |= ( (1<<7) | (1<<6) | (1<<5) | (1<<4) ) ;//불을 끈다 1이 들어오면 꺼지니 캐소드타입
	//
	//PORTF = fndFont[fndNum/10%10];
	//PORTE &= ~(1<<6);
	////PORTF = fndFont[3];
	//_delay_ms(1);
	//
	//
	//PORTE |= (1<<7) | (1<<6) | (1<<5) | (1<<4) ; //불을 끈다 1이 들어오면 꺼지니 캐소드타입
	//PORTF = fndFont[fndNum%10];
	//PORTE &= ~(1<<7);
	//
	////PORTF = fndFont[4];
	//_delay_ms(1);


//ISR 만들어주는부분
ISR(TIMER0_OVF_vect) //인터럽트 발생하면 일로옵니다  이  ISR이 호출되려면 정확히 1m/s? 
{
	FND_ISR_Process();
	// FND_dispNum(fndData);
	TCNT0 = 131;
	incTick();
	
	
	
}
ISR(TIMER2_COMP_vect) //인터럽트 발생하면 일로옵니다  이  ISR이 호출되려면 정확히 1m/s?
{
	
	StopWatch_incMilisec();
	
	
}

int main()
{
	
	StopWatch_init();
	sei();
	//
	//FND_init();
	//
	//
	//TIM0_OVF_init();
	//TIM2_CTC_init();
	
	while(1)
	{
		StopWatch_run();
		

	}
	
}

#if 0
int main()
{
	FND_init();
	
	// uint32_t timeTick = 0;   //이미 커먼에서 선언했으니깐 필요없떵
	static uint32_t prevTime = 0 ;
	TIM0_OVF_init();
	TIM2_CTC_init();
	
	//uint8_t fndFont[10] = {0x3f,0x06,0x5b,0x4f,0x66,0x7d,0x07,0x7f,0x67};
		
	
		#if 0
		//timer/counter 0 번에 대한 overflow interrupt 설정
		
		
		//prescaler 1/1024 로 설정하는 방법은 뭘바야하냐 data sheet 보고
		//cs02 (1) cs01 (1)  cs00 (1)       
		//TCCR0 |= (0<< CS02) |  (0<<CS01) |(1<<CS00);       //001로하면 너무 빨라서 켜져있는것같아
		TCCR0 |= (1<< CS02) |  (0<<CS01) |(1<<CS00);
		
		//TIMSL 마스크 설정 타이머 오버플로우 인터럽트 인에이블
		TIMSK |= (1<<TOIE0); // 1로 넣어주는 식
		#endif
		
		//GLOBAL Interrupt Enable
		sei(); //이함수 호출하면 글로벌 인터럽트 호출하는 함수
		
		//이제 오버플로우가 날때 인터럽트가 일어난다 
		
		uint8_t upCountState = STOP;
		
		uint16_t counter = 0;
		
		button_t btnRunStop,btnReset;
		
		Button_init(&btnRunStop,&DDRA,&PINA,0);
		Button_init(&btnReset,&DDRA,&PINA,1);
		
	while(1)
	{
		
		switch(upCountState)
		{
			case STOP :
			if(Button_GetState((&btnRunStop))==ACT_RELEASED)
			{
				upCountState = RUN;
			}
			else if(Button_GetState(&btnReset)==ACT_RELEASED)
			{
				upCountState = RESET;
			}
			break;
			
			case RUN :
			if(Button_GetState((&btnRunStop))==ACT_RELEASED)
			{
				upCountState = STOP;
			}
			
			break;
			
			case RESET :
			upCountState = STOP;
		}
		
		switch(upCountState)
		{
			case STOP :
			FND_setfndData(counter);
			
			break;
			
			case RUN :
			if(getTick() - prevTime >= 1000)
			{
				
				prevTime = getTick();
				FND_setfndData(counter++);
			}
			
			break;
			
			case RESET :
			counter = 0;
		}
		
		
		//PORTD ^= (1<<7);
		

		
		//FND_dispNum((fndData));
		
		
		//if(timeTick - prevTime >= 100)
		//{
			//
			//prevTime = timeTick;
			//fndData++;
		//}
		//_delay_ms(1);
		//timeTick++;
		//
										
		
		
		//PORTE = ~(1<<4);
		////PORTE = 0b00000000;
		//for(int i =0 ;i<10;i++)
		//PORTF = fndFont[i];
		//_delay_ms(200);
		//
	}
	
}

#endif











#if 0

int main(void)
{
	DDRE = 0xff;
	DDRF = 0xff;
	int N[19]={0,0,0,N0,N1,N0,DAS,N4,N4,N8,N8,DAS,N6,N8,N8,N5,0,0,0};
	int i = 0;
	int j = 0;
	int D[4]={D4,D3,D2,D1};
	
	
	while(1)
	{
		
		for(i=0;i<16;i++)
		{
		for(j=0;j<200;j++)
		{
		
		PORTE = D[0];
		PORTF = N[i];
		_delay_ms(01);
		
		PORTE = D[1];
		PORTF = N[i+1];
		
		_delay_ms(1);
		
		PORTE = D[2];
		
		PORTF = N[i+2];
		_delay_ms(1);
		
		PORTE = D[3];
		PORTF = N[i+3];
		_delay_ms(1);
		}
		}
		
		
	//
		//for(i=0;i<16;i++)
		//{
			//for(j=0;j<200;j++)
			//{
				//
				//PORTE = D[0];
				//PORTF = N[i];
				//_delay_ms(01);
				//
				//PORTE = D[1];
				//PORTF = N[i+1];
				//
				//_delay_ms(1);
				//
				//PORTE = D[2];
				//
				//PORTF = N[i+2];
				//_delay_ms(1);
				//
				//PORTE = D[3];
				//PORTF = N[i+3];
				//_delay_ms(1);
			//}
		//}
		//
		
		

	}


}
#endif


#if 0
int main(void)
{
	DDRE = 0xff;
	DDRF = 0xff;
	while(1)
	{
		//PORTE = 0b01110000; //1의자리 비트를 바꿔주면
		PORTE = D3;  //키고 싶은 부분을 0으로 만들어주면된다
		
		
		PORTF = 0b00111111; //0
		_delay_ms(1000);
		
		PORTF = 0b00000110; //1
		_delay_ms(1000);
		
		PORTF = 0x5b;
		_delay_ms(1000);
		
		PORTF = 0x4f;
		_delay_ms(1000);
		
		PORTF = 0x66;
		_delay_ms(1000);
		
		PORTF = 0x6d;
		_delay_ms(1000);
		
		PORTF = 0x7d;
		_delay_ms(1000);
		
		PORTF = 0x07;
		_delay_ms(1000);
		
		PORTF = 0x7f;
		_delay_ms(1000);
		
		PORTF = 0x67;
		_delay_ms(1000);

	}
	
}
#endif


// test
#if 0
int main(void)
{
    DDRE = 0xff;
	DDRF = 0xff;
	   while (1) 
    {
		for(int i = 0; i<4;i++)
		{
			PORTE = ~(1<<(i+4));
			for(int j = 0; j<8 ; j++ )
			{
				PORTF = 1<<j;
				_delay_ms(100);
			}
			
		}
	}
}
#endif

